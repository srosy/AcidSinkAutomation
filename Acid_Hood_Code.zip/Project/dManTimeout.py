'''**********************************
* Save Entry
* Author: Spencer Rosenvall
* Timeout frame for dman timer when
* too many seconds have passed
**********************************'''
from Tkinter import *
import os
import time

def dManTimeout():

    global popup
    
    popup = Tk()
    popup.title("Timeout...") 
    popup.attributes('-topmost', 1)
    popup.geometry('350x250+75+250')
    
    message = Label(popup, font=('Times', 15), text="User failed to hold deadman switch twice.\nDeadman timer max reached,\n proceeding to drain and rinse 3x\n as per safety procedure.")
    message.pack()

    space = Label(popup, text=' ', font=('Times', 20)).pack()


    okayB = Button(popup, height = 5, width = 25,  text="Okay", command=popup.destroy)
    okayB.pack()
    popup.mainloop()



def warningMessage():

    global popup2
    
    popup2 = Tk()
    popup2.title("Timeout...") 
    popup2.attributes('-topmost', 1)
    popup2.geometry('350x200+75+250')
    
    message = Label(popup2, text="***WARNING***\nFailure to hold deadman switch again\nmay result in Automatic Drain&Rinse",
                    font=("Times", 15))
    message.pack()

    space = Label(popup2, text=' ', font=('Times', 20)).pack()

    okayB = Button(popup2, text="Okay", command=popup2.destroy,
                   height = 5, width = 25)
    okayB.pack()
    popup2.mainloop()








            
