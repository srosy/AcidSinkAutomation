'''
    Author: Spencer Rosenvall
    Date: 4/20/2018
    Class: Class add_remove_user modifys existing user credential log
    by removing or adding users of different types to the text file.
    
'''

class add_remove_user:

    global userlist
    userlist = 'User_Credentials.txt'
    global user_exists
    user_exists = 0

    def check_for_user(self, user):
        with open(userlist, 'r') as f:
            global user_exists
            users_in_list = f.read()
            user_exists = 0
            if(user) in users_in_list:
                f.close
                user_exists = 1
            else:
                f.close
                user_exists = 0

    def add_user(self, user, user_type):
        self.check_for_user(user) #check if user exists
        if(user_exists is 1):
            print "User already exists."
        else:
            with open(userlist, 'a') as f:
                f.write(user_type+':'+user+'\n')
                print ('adding user: %s' %user)

    def remove_user(self, user):
        self.check_for_user(user) # check if user exists
        if(user_exists is 1):
            with open(userlist, 'r') as f:
                lines = f.readlines()
                f.close()
            with open(userlist, 'a') as f:
                f.seek(0)
                f.truncate()
                for line in lines:
                    if ((line == 'user:'+user+'\n')
                        or (line == 'maintenance:'+user+'\n')
                        or (line == 'super:'+user+'\n')):
                            print ('removing user: %s' %user)
                    else:
                        f.write(line)
                        
                f.close()

        else:
            print "User doesn't exist."



    
# Testing

#test = add_remove_user()
#test.add_user("test", "user")
##test.remove_user("testytesttest", "user")
#test.remove_user("test")
#print "done"

        


        
    
