'''******************************
* Author: Spencer Rosenvall
* Drip Tray Leak Detector Thread:
* Checks sensor ever two seconds
* if leak is detected
*******************************'''
import threading
from threading import *
import RPi.GPIO as GPIO
import time

#class LeakThread:




        
def alarmOff():
        GPIO.output(16, 0) #Alarm OFF
        #print "Alarm OFF"

def alarmOn():
        GPIO.output(16, 1) #Alarm ON
        #print "Alarm ON"
        

                
#checkLeak()
                
