'''**************************
* Save Entry
* Author: Spencer Rosenvall
**************************'''
from Tkinter import *
import os, sys
import time
import datetime

reason = 'logged_reasons_fill1.txt'
reason2 = 'logged_reasons_fill2.txt'
reason3 = 'logged_reasons_fill3.txt'
reason4 = 'logged_reasons_fill4.txt'
log = 'userLog.txt'

# popup to record user and why recipe change is necessary.
def popupFrame(r):
    global userEntry
    global popupMessageEntry
    global popup
    
    popup = Tk()
    popup.title("Record Change")
    popup.attributes('-topmost', 1)
    popup.geometry('375x137+50+250')
    
    user = Label(popup, text='User making Change: ', font=('Times', 15))
    user.grid(row=1, sticky=W)
    userEntry = Entry(popup)
    userEntry.grid(row=1, column = 1)
    
    message = Label(popup, text="Reason for change:", font=('Times', 15))
    message.grid(row=2, sticky=W)
    popupMessageEntry = Entry(popup)
    popupMessageEntry.grid(row=2, column=1)

    space = Label(popup, text=" ", font=('Times', 10))
    space.grid(row=3, sticky=W)

    if r == 1:
        recordB = Button(popup, text="Record Data", command=recordData, height=3, width = 20)
    if r == 2:
        recordB = Button(popup, text="Record Data", command=recordData2, height=3, width = 20)
    if r == 3:
        recordB = Button(popup, text="Record Data", command=recordData3, height=3, width = 20)
    if r == 4:
        recordB = Button(popup, text="Record Data", command=recordData4, height=3, width = 20)
    recordB.grid(column=0, row=4)
    popup.mainloop()
    

def recordData():
        with open(reason, 'a+') as f:
            f.write("Date and time: " + time.strftime("%c\n"))
            f.write("User: " + userEntry.get())
            f.write(" Reason: " + popupMessageEntry.get())
            f.write("\n\n")
            f.close()
            popup.destroy()
            
def recordData2():
        with open(reason2, 'a+') as f:
            f.write("Date and time: " + time.strftime("%c\n"))
            f.write("User: " + userEntry.get())
            f.write(" Reason: " + popupMessageEntry.get())
            f.write("\n\n")
            f.close()
            popup.destroy()

def recordData3():
        with open(reason3, 'a+') as f:
            f.write("Date and time: " + time.strftime("%c\n"))
            f.write("User: " + userEntry.get())
            f.write(" Reason: " + popupMessageEntry.get())
            f.write("\n\n")
            f.close()
            popup.destroy()

def recordData4():
        with open(reason4, 'a+') as f:
            f.write("Date and time: " + time.strftime("%c\n"))
            f.write("User: " + userEntry.get())
            f.write(" Reason: " + popupMessageEntry.get())
            f.write("\n\n")
            f.close()
            popup.destroy()
            

def loginUser(currentUser):
        with open(log, 'a+') as f:
            f.write("----------------------------------------------------------------------------\n\nDate and time: " + time.strftime("%c\n"))
            f.write("User: " + currentUser + " LOGGED IN") #write var currentUser, assign to user that logged in, in main code and return
            f.write("\n\n")
            f.close()


def logFunction(currentUser, functionCalled):
        with open(log, 'a+') as f:
            f.write("Date and time: " + time.strftime("%c\n"))
            f.write("User: " + currentUser) #write var currentUser, assign to user that logged in, in main code and return
            f.write(" Fuction Called: " + functionCalled) #write functionCalled and have it return val from main code
            f.write("\n\n")
            f.close()

def logFunction2(currentUser, functionCalled):
        with open(log, 'a+') as f:
            f.write("\n\nDate and time: " + time.strftime("%c\n"))
            f.write("User: " + currentUser) #write var currentUser, assign to user that logged in, in main code and return
            f.write(" Fuction Called: " + functionCalled) #write functionCalled and have it return val from main code
            f.write("\n\n----------------------------------------------------------------------------")
            f.close()
            

def logoutUser(currentUser):
        with open(log, 'a+') as f:
            f.write("Date and time: " + time.strftime("%c\n"))
            f.write("User: " + currentUser + " LOGGED OUT") #write var currentUser, assign to user that logged in, in main code and return
            f.write("\n\n----------------------------------------------------------------------------")
            f.close()

def timeoutLogoutUser(currentUser):
        with open(log, 'a+') as f:
            f.write("Date and time: " + time.strftime("%c\n"))
            f.write("User: " + currentUser + " SESSION TIMED-OUT") #write var currentUser, assign to user that logged in, in main code and return
            f.write("\n\n----------------------------------------------------------------------------")
            f.close()
