'''**************************
* GUI Acid Hoods
* Author: Spencer Rosenvall
* Version: 1.1.24
**************************'''
# !/usr/bin/env python
# Libraries from python
from Tkinter import *
import Tkinter as tk
import RPi.GPIO as GPIO
import itertools
import time
import sys
import os


# Modules in the script folder
from threading import *
from dManTimeout import *
from saveEntry import *
from timeoutThread import *
from leakThread import *
from add_removeUser import *
from Thermocouple import *

#Global Pin Var Settings
global alreadyOperating #control bit that keeps multiple commands from happening at once.
alreadyOperating = 0
global allowNoStop # control bit that forces penalty Drain and Rinse to operate until finished.
allowNoStop = 0
global superUser #developer rights = 1
superUser = 0
global isSupervisor # supervisor rights = 1
isSupervisor = 0
global maintenanceUser # maintenance rights = 1
maintenanceUser = 0
global leakThreadPin # pin for Leaksensors
leakThreadPin = 18
global interlockThreadPin # pin for Leaksensors
interlockThreadPin = 11
global n2Pin # pin for n2Curtain
n2Pin = 37
global photohelicPin # pin for photohelic low alarm
photohelicPin = 24

#Thermocouple pins
cs_pin = 38
clock_pin = 40
data_pin = 36
units = "f"
tempTrigger = 210 # temperature setpoint for thermocouple to trigger alarm (220F)


################# Default Settings #####################

global timeoutTime # time for the timeout
timeoutTime = 3600 # one hour (seconds)

global stopPressed # control bit to determine if stop has been pressed during recipes, that way timers can stop too.
stopPressed = False

global r #LeakDetector Rinse
r = 1 #rinse cycle for LeakDetector Rinse set to 1
global checkLeakTime
checkLeakTime = 2

global rinseTime # time it takes for water to fill up tank for once cycle
rinseTime = 450 #if double sink hood: 105

global drainTime #time it takes to drain once (secs)
drainTime = 210 #if double sink hood: 105

global penaltyTime # time it takes for penalty to be applied when no deadman detection during filling sequence
penaltyTime = 30

global cb
cb = 0 # control bit for LeakSensors
global yesMaintenance # second control bit for LeakSensor that will allow maintenance to work while thread still monitors
yesMaintenance = 0


#Water first fill default times
global waterFill1Time
waterFill1Time = 40 #Fill 1 (seconds), initial water fill time
global waterFill2Time
waterFill2Time = 2 #Fill 2 (seconds), initial water fill time
global waterFill3Time 
waterFill3Time = 3 #Fill 3 (seconds), initial water fill time
global waterFill4Time 
waterFill4Time = 5 #Fill 4 (seconds), initial water fill time
global waterFill5Time 
waterFill5Time = 10 #Fill 5 (seconds), initial water fill time
global waterFill6Time 
waterFill6Time = 15 #Fill 6 (seconds), initial water fill time
global waterFillVTime
waterFillVTime = 7 #Fill V (seconds), initial water fill time


# HF fill default times
global hfFill1Time
hfFill1Time = 20 #Fill 1 (seconds)
global hfFill2Time 
hfFill2Time = 7 #Fill 2 (seconds)
global hfFill3Time
hfFill3Time = 7 #Fill 3 (seconds)
global hfFill4Time
hfFill4Time = 5 #Fill 4 (seconds)
global hfFill5Time
hfFill5Time = 10 #Fill 5 (seconds)
global hfFill6Time
hfFill6Time = 15 #Fill 6 (seconds)
global hfFillVTime
hfFillVTime = 7 #Fill V (seconds)

# NHO3 fill default times
global nhFill1Time
nhFill1Time = 10 #Fill 1 (seconds)
global nhFill2Time
nhFill2Time = 7 #Fill 2 (seconds)
global nhFill3Time
nhFill3Time = 7 #Fill 3 (seconds)
global nhFill4Time
nhFill4Time = 5 #Fill 4 (seconds)
global nhFill5Time
nhFill5Time = 10 #Fill 5 (seconds)
global nhFill6Time
nhFill6Time = 15 #Fill 6 (seconds)
global nhFillVTime
nhFillVTime = 7 #Fill V (seconds)

# Final Water Fill default times
global FWFillTime
FWFillTime = 17 # Fill 1 (seconds), concluding water seconds
global FWFillTime2
FWFillTime2 = 5 # Fill 2 (seconds), concludint water seconds
global FWFillTime3
FWFillTime3 = 5 # Fill 3 (seconds),  concluding water seconds
global FWFillTime4
FWFillTime4 = 5 # Fill 4 (seconds),  concluding water seconds
global FWFillTime5
FWFillTime5 = 10 # Fill 5 (seconds),  concluding water seconds
global FWFillTime6
FWFillTime6 = 15 # Fill 6 (seconds),  concluding water seconds
global FWFillTimeV
FWFillTimeV = 5 # Fill V (seconds),  concluding water seconds


# Holding default times
global holdSecFill
holdSecFill = 0
global holdSecFill1
holdSecFill1 = 30 #time to hold acid in tank after filling for fill 1
global holdSecFill2
holdSecFill2 = 7 #time to hold acid in tank after filling for fill 2
global holdSecFill3
holdSecFill3 = 9 #time to hold acid in tank after filling for fill 3
global holdSecFill4
holdSecFill4 = 5 #time to hold acid in tank after filling for fill 3
global holdSecFill5
holdSecFill5 = 10 #time to hold acid in tank after filling for fill 3
global holdSecFill6
holdSecFill6 = 15 #time to hold acid in tank after filling for fill 3
global holdSecFillV
holdSecFillV = 11 #time to hold acid in tank after filling for fill V 1


#Frame Stack Layout
class FrameLayout(tk.Tk):
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        frameContainer = tk.Frame(self)
        frameContainer.pack(side="top", fill='x')
        frameContainer.grid_rowconfigure(0, weight=1)
        frameContainer.grid_columnconfigure(0, weight=1)
        self.frames = {}

        for F in (MainMenu, FillProcMenu, FillChangeFrame, ChangeRecipeFrame, toFillVFrame,
                  ChangeRecipeFrame_Fill2,
                  ChangeRecipeFrame_Fill3,
                  ChangeRecipeFrame_Fill4,
                  ChangeRecipeFrame_Fill5,
                  ChangeRecipeFrame_Fill6,
                  ChangeRecipeFrame_Fill_Variable,
                  OptionFrame, userFrame, MaintenanceFrame,
                  LeakDetectedFrame, OverflowDetectedFrame,
                  InterlockFrame):
            
            frame = F(frameContainer, self)

            self.frames[F] = frame

            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(MainMenu)

    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()

        
# Main Menu
class MainMenu(tk.Frame):

    
    def __init__(self, parent, controller):

        openDrain()
        global isSupervisor
        isSupervisor = 0

        def setCB(num):
            global cb
            if (num == 0):
                    cb = 0
            if (num == 1):
                    cb = 1
            else:
                    return

        def rinseXTimes():
            global r
            for r in range (1, 5):
                print ("Water set to fill for %d seconds before auto drain commencement . ." % rinseTime)
                rinse()
                global currentRinseTime
                currentRinseTime = rinseTime #rinseTime is global default time to rinse
                def continueRinse():
                    text.yview(END)
                    print ("Seconds left to FILL for rinse: %s" % currentRinseTime)
                    print ("Filling cycle: %s" % r)
                    global currentRinseTime
                    currentRinseTime = currentRinseTime - 1
                    if (currentRinseTime == -1):
                        text.yview(END)
                        print ("Filling cycle: %s complete, proceeding to DRAIN..." % r)
                        drain()
                        time.sleep(drainTime) #time it takes to drain
                    else:
                        time.sleep(1)
                        continueRinse()
                continueRinse()
            return

        def getReading():
            time.sleep(.5) #delay thread initlialization so program can load
            while (True):
                try:
                    if (cb == 0 and GPIO.input(leakThreadPin) == 0 and yesMaintenance == 0):
                        try:
                            print ("leak detected during %d" % functionCalled)
                        except:
                            pass
                        text.yview(END)
                        allLow2()#close all valves
                        alarmOn()#functions.py
                        setCB(1)
                        text.yview(END)
                        controller.show_frame(LeakDetectedFrame)
                        #rinseXTimes()
                        time.sleep(.5)
                    elif (cb == 1 and GPIO.input(leakThreadPin) == 0):
                        try:
                            print ("leak detected during %d" % functionCalled)
                        except:
                            pass
                        try:
                            print ("Number of completed rinses prior to activation: %d" % ((autoNumberTimesLeft - 3) * -1))
                        except:
                            pass
                        print "system awaiting maintenance . . ."
                        text.yview(END)
                        time.sleep(5)
                    else:
                        time.sleep(checkLeakTime)
                except:
                    print "leak thread not working..."
                    time.sleep(.5)
                    pass

        def photohelicThread():
            time.sleep(.5) #delay thread initlialization so program can load
            while (True):
                try:
                    if (GPIO.input(photohelicPin) == 0):
                        alarmOn()
                        #print "alarm on"
                        print "Photohelic LOW"
                        print "system awaiting maintenance\n\n"
                        text.yview(END)
                        time.sleep(.5)
                    else:
                        alarmOff()
                        #print "alarm off"
                        time.sleep(checkLeakTime)
                except:
                    print "Photohelic thread not working..."
                    time.sleep(.5)
                    pass


        def thermoCoupleThread():
            time.sleep(.5) #delay thread initlialization so program can load
            thermocouple = MAX31855(cs_pin, clock_pin, data_pin, units)
            global temp
            temp = 0
            while (True):
                try:
                    global temp
                    temp = thermocouple.get() # get the temperature of the thermocouple
                    
                    if (temp >= tempTrigger):
                        time.sleep(.5)
                        if(temp >= tempTrigger):
                            alarmOn()
                            print ("Thermocouple temp: %dF" % temp)
                            print "System awaiting maintenance\n\n\n\n"
                            text.yview(END)
                        time.sleep(.5)
                    else:
                        alarmOff()
                        time.sleep(checkLeakTime)
                except:
                    print "thermocouple thread not working..."
                    time.sleep(.5)
                    pass


        def overFlowMonitor():
            time.sleep(.5) #delay thread initlialization so program can load
            while (True):
                    try:
                        if (cb == 0 and GPIO.input(22) == 0 and yesMaintenance == 0):
                            try:
                                print ("Overflow detected during %d" % functionCalled)
                            except:
                                pass
                            text.yview(END)
                            allLow2()#close all valves
                            openDrain()
                            alarmOn()#functions.py
                            setCB(1)
                            text.yview(END)
                            controller.show_frame(OverflowDetectedFrame)
                            #rinseXTimes()
                            time.sleep(.5)
                        elif (cb == 1 and GPIO.input(22) == 0):
                            try:
                                print ("Overflow detected during %d" % functionCalled)
                            except:
                                pass
                            try:
                                print ("Number of completed rinses prior to activation: %d" % ((autoNumberTimesLeft - 3) * -1))
                            except:
                                pass
                            print "system awaiting maintenance . . ."
                            text.yview(END)
                            time.sleep(5)
                        else:
                            time.sleep(checkLeakTime)
                    except:
                        print "overflow thread not working..."
                        time.sleep(.5)
                        pass


        def interlockMonitor():
            time.sleep(.5) #delay thread initlialization so program can load
            while (True):
                    try:
                        if (cb == 0 and GPIO.input(interlockThreadPin) == 1 and yesMaintenance == 0):
                            try:
                                print ("Interlock disruption detected during %d" % functionCalled)
                            except:
                                pass
                            text.yview(END)
                            allLow2()#close all valves
                            alarmOn()#functions.py
                            setCB(1)
                            text.yview(END)
                            controller.show_frame(InterlockFrame)
                            #rinseXTimes()
                            time.sleep(.5)
                        elif (cb == 1 and GPIO.input(22) == 0):
                            try:
                                print ("Interlock disruption detected during %d" % functionCalled)
                            except:
                                pass
                            try:
                                print ("Number of completed rinses prior to activation: %d" % ((autoNumberTimesLeft - 3) * -1))
                            except:
                                pass
                            print "system awaiting maintenance . . ."
                            text.yview(END)
                            time.sleep(5)
                        else:
                            time.sleep(checkLeakTime)
                    except:
                        print "interlock not working..."
                        time.sleep(.5)
                        pass
                    
                
        def startThreads():

                # checkLeakThread Initialization
                try:
                    print "starting leakThread . . ."
                    print ("LeakSensors state: %s" % GPIO.input(leakThreadPin))
                    global th
                    th = threading.Thread(name = 'checkLeak', target = getReading)
                    th.start()
                except:
                    print "Leak Thread failed to start"

                # OverflowThread Initialization
                try:
                    print "Starting overflowThread"
                    overFillProtection = threading.Thread(name = 'overFlowMonitor', target=overFlowMonitor)
                    overFillProtection.start()
                except:
                    print "Failed to start overFillProtection"

                # InterlockThread Initialization
                try:
                    print "starting interlockThread"
                    interlockThread = threading.Thread(name = 'interlockMonitor', target=interlockMonitor)
                    interlockThread.start()
                except:
                    print "Failed to start interlockThread"

                # ThermocoupleThread Initialization
                try:
                    print "starting thermocoupleThread"
                    thermocoupleThread = threading.Thread(name = 'thermocoupleThread', target=thermoCoupleThread)
                    thermocoupleThread.start()
                except:
                    print "Failed to start interlockThread"

                # PhotohelicThread Initialization
                try:
                    print "starting photohelicThread"
                    PhotohelicThread = threading.Thread(name = 'PhotohelicThread', target=photohelicThread)
                    PhotohelicThread.start()
                except:
                    print "Failed to start photohelicThread"

        startThreads()
        print cb
        print GPIO.input(leakThreadPin)
        print yesMaintenance
            
        
        #User recipe login      
        def getCredentials_User(event):
            creds = 'User_Credentials.txt'
            def Login():
                global nameEL
                global pwordEL 
                global rootA
                rootA = Tk() 
                rootA.attributes('-topmost', 1)
                rootA.geometry('400x160+37+275')
                rootA.title('Login') 
                nameL = Label(rootA, text='Employee Id: ', font=('Times', 20))
                nameL.pack()
                spaceLabel = Label(rootA, text=' ', font = ('Times', 10))
                spaceLabel.pack()
                nameEL = Entry(rootA, font = ('Times', 18)) 
                nameEL.pack()
                spaceLabel2 = Label(rootA, text=' ', font = ('Times', 10))
                spaceLabel2.pack()
                loginB = Button(rootA, text='Login', command=CheckLogin, height = 3, width = 15)
                loginB.pack()
                rootA.bind('<Return>', CheckLogin)
        
                rootA.mainloop()


            # Check whether supervisor is logging in
            def checkSupervisor():
                with open(creds) as f:
                        data = f.read()
                        if ("super:" + nameEL.get()) in data:
                            global isSupervisor
                            isSupervisor = 1
                
                
            def CheckLogin(event=None):
                with open(creds) as f:
                    data = f.read()
                    if (nameEL.get() == "dev"):
                        global superUser #control var to give developer rights
                        superUser = 1 #1 = developer
                        print "Developer logged in"
                        text.yview(END)
                        global currentUser
                        currentUser = nameEL.get()
                        loginUser(currentUser) #record when which user logs in
                        rootA.destroy()
                        program.attributes('-zoom', True) #Give the developer access to quit program
                        controller.show_frame(FillProcMenu)
                    elif (nameEL.get() == ""):
                        text.yview(END)
                        print "Please enter credentials.\n\n\n\n\n"
                        text.yview(END)
                    else:
                        checkSupervisor()
                        global isSupervisor
                        if (isSupervisor is 1):
                            global currentUser
                            currentUser = nameEL.get()
                            loginUser(currentUser) #record when which user logs in
                            controller.show_frame(FillProcMenu)
                            rootA.destroy()
                            print ("Supervisor %s successfully logged in.\n\n\n\n\n" % currentUser)
                            text.yview(END)
                            controller.show_frame(FillProcMenu)
                        elif ("maintenance:" + nameEL.get()) in data:
                            global maintenanceUser
                            maintenanceUser = 1
                            currentUser = nameEL.get()
                            loginUser(currentUser) #record when which user logs in
                            controller.show_frame(FillProcMenu)
                            rootA.destroy()
                            print ("Maintenance %s successfully logged in.\n\n\n\n\n" % currentUser)
                            text.yview(END)
                            controller.show_frame(FillProcMenu)              
                        else:
                            with open(creds) as f:
                                global currentUser
                                currentUser = nameEL.get()
                                data = f.read()
                                f.close()

                                if ("user:" + nameEL.get()) in data: #making sure pass and name are respected
                        
                                    loginUser(currentUser) #record when which user logs in
                                    
                                    controller.show_frame(FillProcMenu)
                                    rootA.destroy()
                                    text.yview(END)
                                    print ("%s successfully logged in." % currentUser)
                                    print "\n\n\n\n\n"
                                    controller.show_frame(FillProcMenu)
                                    
                                    def threadLogout():
                                        controller.show_frame(MainMenu)
                                        timeoutLogoutUser(currentUser) #record when which user logs out
                                        global superUser
                                        superUser = 0
                                        global isSupervisor # sets supervisor control bit back to 0
                                        isSupervisor = 0
                                        print "Session timed out . . ."
                                        text.yview(END)
                                        
                                    print "Session started . . ."
                                    global t
                                    t = Timer(timeoutTime, threadLogout)
                                    t.start()

                                    

                                else:
                                    r = Tk()
                                    r.title('D:')
                                    r.attributes('-topmost', 1)
                                    r.geometry('150x50+75+275')
                                    rlbl = Label(r, text='\n[!] Invalid Login')
                                    rlbl.pack()
                                    r.mainloop()
            Login()

            #User options login      
        def getCredentials_User_Options(event):
            creds = 'User_Credentials.txt'
            def Login():
                global nameEL
                global pwordEL 
                global rootA
                rootA = Tk() 
                rootA.attributes('-topmost', 1)
                rootA.geometry('400x160+37+275')
                rootA.title('Login') 
                nameL = Label(rootA, text='Employee Id: ', font=('Times', 20))
                nameL.pack()
                spaceLabel = Label(rootA, text=' ', font = ('Times', 10))
                spaceLabel.pack()
                nameEL = Entry(rootA, font = ('Times', 18))
                nameEL.pack()
                spaceLabel2 = Label(rootA, text=' ', font = ('Times', 10))
                spaceLabel2.pack()
                loginB = Button(rootA, text='Login', command=CheckLogin, height = 3, width = 15)
                loginB.pack()
                rootA.bind('<Return>', CheckLogin)
        
                rootA.mainloop()


            # Check wiether supervisor is logging in
            def checkSupervisor():
                with open(creds) as f:
                        data = f.read()
                        if ("super:" + nameEL.get()) in data:
                            global isSupervisor
                            isSupervisor = 1
                
                
            def CheckLogin(event=None):
                with open(creds) as f:
                    data = f.read()
                    if (nameEL.get() == "dev"):
                        global superUser # control var to give developer rights
                        superUser = 1 # 1 = developer
                        print "Developer logged in"
                        text.yview(END)
                        global currentUser
                        currentUser = nameEL.get()
                        loginUser(currentUser) #record when which user logs in
                        rootA.destroy()
                        program.attributes('-zoom', True) #Give the developer access to quit program
                        controller.show_frame(OptionFrame)
                    elif (nameEL.get() == ""):
                        text.yview(END)
                        print "Please enter credentials.\n\n\n\n"
                        text.yview(END)
                    else:
                        checkSupervisor()
                        global isSupervisor
                        if (isSupervisor is 1):
                            global currentUser
                            currentUser = nameEL.get()
                            loginUser(currentUser) #record when which user logs in
                            controller.show_frame(OptionFrame)
                            rootA.destroy()
                            print "Supervisor successfully logged in.\n\n\n\n\n"
                            text.yview(END)
                            controller.show_frame(OptionFrame)
                        elif ("maintenance:" + nameEL.get()) in data:
                            global maintenanceUser
                            maintenanceUser = 1
                            currentUser = nameEL.get()
                            loginUser(currentUser) #record when which user logs in
                            controller.show_frame(OptionFrame)
                            rootA.destroy()
                            print "Maintenance user successfully logged in.\n"
                            text.yview(END)
                            controller.show_frame(OptionFrame)              
                        else:
                            with open(creds) as f:
                                global currentUser
                                currentUser = nameEL.get()
                                data = f.read()
                                f.close()

                                if ("user:" + nameEL.get()) in data: #making sure pass and name are respected
                                    rootA.destroy()
                                    text.yview(END)
                                    print "Failed to log in\n"
                                    text.yview(END)
                                    
            Login()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Acid Sink\nCleaning Interface", font=('Times', 40))
        label.pack(pady=10, padx=10)

        picPath = '/home/pi/Desktop/Project/flash.gif'
        flashPic = tk.PhotoImage(file=picPath)
        labelPic = tk.Label(self, image=flashPic)
        labelPic.image = flashPic
        labelPic.pack(pady=10)
 
        button1 = tk.Button(self, text="Recipes", width = 25, height=8)
        button1.bind("<Button-1>", getCredentials_User)
        button1.pack()

        button2 = tk.Button(self, text="Options", width = 25, height=8)
        button2.bind("<Button-1>", getCredentials_User_Options)
        button2.pack()

        
# Options Menu
class OptionFrame(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

        def killProgram():
            if (isSupervisor):
                logFunction2(currentUser, "Terminated Program")
                os._exit(0)
            else:
                print 'Access Denied'
                text.yview(END)

        def toFillV():
            if (isSupervisor):
                controller.show_frame(toFillVFrame)
            else:
                print 'Access Denied'
                text.yview(END)
                
        def toChangeFill():
            if (isSupervisor):
                controller.show_frame(FillChangeFrame)
            else:
                print 'Access Denied'
                text.yview(END)

        def toAddRemove():
            if (isSupervisor):
                controller.show_frame(userFrame)
            else:
                print 'Access Denied'
                text.yview(END)

        def restart():
            if (isSupervisor):
                restart_program()
            else:
                print 'Access Denied'
                text.yview(END)

        def returnToStart():
            global isSupervisor
            global maintenanceUser
            isSupervisor = 0
            maintenanceUser = 0
            controller.show_frame(MainMenu)
            
        
        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Options", font=('Times', 30))
        label.pack(pady=10, padx=10)

        button1 = tk.Button(self, text="Fill Variable", width=25, height=4,
                            command=toFillV)
        button1.pack()
        
        button4 = tk.Button(self, text="Change Fill Recipe", width=25, height=4,
                            command=toChangeFill)
        button4.pack()

        button1 = tk.Button(self, text="Maintenance", width=25, height=4,
                            command=lambda: controller.show_frame(MaintenanceFrame))
        button1.pack()

        button5 = tk.Button(self, text="Add / Remove User", width=25, height=4,
                            command=toAddRemove)
        button5.pack()

        button3 = tk.Button(self, text="Restart", width = 25, height=4,
                            command=restart)
        button3.pack()

        button5 = tk.Button(self, text="Exit Program", width = 25, height=4,
                            command=killProgram)
        button5.pack()

        button2 = tk.Button(self, text="Return", width = 25, height=4,
                           command=returnToStart)
        button2.pack()

        label3 = tk.Label(self, text=" ", font=('Times', 2))
        label3.pack(pady=10)


# Add/Remove User Menu
class userFrame(tk.Frame):
    def __init__(self, parent, controller):

        global normal_checked
        global maintenance_checked
        global supervisor_checked
        normal_checked = 0
        maintenance_checked = 0
        supervisor_checked = 0

        user = add_remove_user() # object class add_remove_user
        

        def normal():
            if(normal_checked is 0):
                buttonM.deselect()
                buttonS.deselect()
                global maintenance_checked
                global supervisor_checked
                maintenance_checked = 0
                supervisor_checked = 0
                global normal_checked
                normal_checked = 1
            else:
                global normal_checked
                normal_checked = 0

        def maintenance():
            if(maintenance_checked is 0):
                buttonN.deselect()
                buttonS.deselect()
                global normal_checked
                global supervisor_checked
                normal_checked = 0
                supervisor_checked = 0
                global maintenance_checked
                maintenance_checked = 1
            else:
                global maintenance_checked
                maintenance_checked = 0

        def supervisor():
            if(supervisor_checked is 0):
                buttonN.deselect()
                buttonM.deselect()
                global normal_checked
                global maintenance_checked
                normal_checked = 0
                maintenance_checked = 0
                global supervisor_checked
                supervisor_checked = 1
            else:
                global supervisor_checked
                supervisor_checked = 0

        def addUser():
            employeeNum = userNum.get()
            if(normal_checked is 1):
                try:
                    user.add_user(employeeNum, "user")
                    text.yview(END)
                    #print ("%s added sucessfully." % employeeNum)
                except:
                    print "User already exists."
                    text.yview(END)
            elif(maintenance_checked is 1):
                try:
                    user.add_user(employeeNum, "maintenance")
                    #print ("Maintenance user %s added sucessfully." % employeeNum)
                    text.yview(END)
                except:
                    
                    print "User already exists."
                    text.yview(END)
            elif(supervisor_checked is 1):
                try:
                    user.add_user(employeeNum, "super")
                    #print ("Super user %s added sucessfully." % employeeNum)
                    text.yview(END)
                except:
                    print "User already exists."
                    text.yview(END)
            else:
                pass
                
        def removeUser():
            employeeNum = userNum.get()
            user.remove_user(employeeNum)
            #print ("%s deleted sucessfully." % employeeNum)
            text.yview(END)
                

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Add/Remove User", font=('Times', 30))
        label.pack(pady=10, padx=10)
        
        label2 = tk.Label(self, text=" ", font=('Times', 10))
        label2.pack(pady=10)

        labelE = tk.Label(self, text="Employee ID #", font=('Times', 20))
        labelE.pack(pady=10)
        

        userNum = tk.Entry(self, text="userNum")
        userNum.pack()
        

        label3 = tk.Label(self, text=" ", font=('Times', 3))
        label3.pack(pady=10)
        

        btnFrame = tk.Frame(self)
        btnFrame.pack()

        labelT = tk.Label(btnFrame, text="Select Type of User", font=('Times', 15))
        labelT.grid(row = 0, column = 1)

        buttonN = tk.Checkbutton(btnFrame, text="Normal", command=normal)
        buttonN.grid(row = 1, column = 0)
        
        buttonM = tk.Checkbutton(btnFrame, text="Maintenance", command=maintenance)
        buttonM.grid(row = 1, column = 1)
        
        buttonS = tk.Checkbutton(btnFrame, text="Supervisor", command=supervisor)
        buttonS.grid(row = 1, column = 2)


        label5 = tk.Label(self, text=" ", font=('Times', 3))
        label5.pack(pady=10)
        

        buttonA = tk.Button(self, text="Add User", width=25, height=5, command=addUser)
        buttonA.pack()
        buttonR = tk.Button(self, text="Remove User", width=25, height=5, command=removeUser)
        buttonR.pack()

        button3 = tk.Button(self, text="Return", width=25, height=5,
                            command=lambda: controller.show_frame(OptionFrame))
        button3.pack()


# Maintenance Frame
class MaintenanceFrame(tk.Frame):
    def __init__(self, parent, controller):

        global hfTimes
        hfTimes = 0
        global nitTimes
        nitTimes = 0
        
        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

        def closeDrain():
            drainClose() # from functions.py
            text.yview(END)


        def toggleDrain():
            if (getDrainStatus()):
                button3.configure(state = "normal", relief = "raised", bg = originalColor)
                closeDrain()
            else:
                saveColor(button3)
                button3.configure(state = "normal", relief = "raised", bg = "lawn green")
                openDrain()
                text.yview(END)

        def checkDrainStatus(): 
            if (getDrainStatus()):
                button3.configure(state = "normal", relief = "raised", bg = "lawn green")
            else:
                button3.configure(state = "normal", relief = "raised", bg = originalColor)

        def rinseOnce():
            if (alreadyOperating == 0):
                global alreadyOperating
                alreadyOperating = 1
                print ("Water set to fill for %d seconds before auto drain commencement . . ." % rinseTime)
                rinse()
                checkDrainStatus()
                global currentRinseTime
                currentRinseTime = rinseTime #rinseTime is global default time to rinse
                def continueRinse():
                    if (alreadyOperating == 0):
                        pass
                    else:
                        print ("Time left to fill for rinse: %s\n\n\n\n\n" % currentRinseTime)
                        global currentRinseTime
                        currentRinseTime = currentRinseTime - 1
                        if currentRinseTime == -1:
                            stop()
                            print "Filling complete, proceeding to drain"
                            openDrain()
                            checkDrainStatus()
                            text.yview(END)
                            global alreadyOperating
                            alreadyOperating = 0 
                        else:
                            text.yview(END)    
                            self.after(1000, continueRinse)
                continueRinse()
            else:
                pass

        def purgeAcidLines():
            purge() # create code from within functions.py
            print "Purging Acid Lines . . ."
            text.yview(END)

        def stopOperations():
            stop()
            print "Stopping all operations . . .\n\n\n\n\n"
            global alreadyOperating
            alreadyOperating = 0
            checkDrainStatus()
            text.yview(END)

        def getSensorStatus(): # get all the sensors status in one click
            getDmanPinStatus()
            getDripStatus()
            getOverFlowStatus()
            getInterlockStatus()
            getphotohelicPinStatus()
            getThermocoupleStatus()
            

        def getDripStatus():
            print ("Leak Detectors status: %s" % GPIO.input(18))
            text.yview(END)

        def getOverFlowStatus():
            print ("OverFlow status: %s" % GPIO.input(22))
            text.yview(END)

        def getInterlockStatus():
            print ("Interlock status: %s" % GPIO.input(interlockThreadPin))
            text.yview(END)
            
        def getThermocoupleStatus():
            print ("Thermocouple status: %dF" % temp)
            text.yview(END)

        def getphotohelicPinStatus():
            print ("Photohelic status: %s" % GPIO.input(photohelicPin))
            text.yview(END)
            
        def getDmanPinStatus():
            print ("Dman Switch status: %s" % GPIO.input(32))
            text.yview(END)

        def returnFrame():
            restart_program() #fucntions.py

        def updateText():
            text.yview(END)

        def clear():
            print "\n\n\n\n\n\n\n"
            text.yview(END)
            
        def saveColor(button): # save default background color
            global originalColor
            originalColor = button.cget("background")
        

        def hfOpen(event):

            if(hfTimes < 3):
                saveColor(buttonHF)
                buttonHF.configure(state = "normal", relief = "raised", bg = "IndianRed1")
                HFOpen() # Functions.py
                text.yview(END)
                time.sleep(1.5) # allow one second for testing
                global hfTimes
                hfTimes += 1
                print ('Allowed button press %d:3' % hfTimes)
                text.yview(END)
                hfCloseAuto()
                
            else:
                print 'Maximum button presses (HF) reached.\n\n\n\n\n'
                text.yview(END)

        def hfClose(event):
            buttonHF.configure(state = "normal", relief = "raised", bg = originalColor)
            HFClose() # Functions.py
            text.yview(END)
        def hfCloseAuto():
            buttonHF.configure(state = "normal", relief = "raised", bg = originalColor)
            HFClose() # Functions.py
            print "\n\n"
            text.yview(END)

        def nitOpen(event):

            if(nitTimes < 3):
                saveColor(buttonNT)
                buttonNT.configure(state = "normal", relief = "raised", bg = "IndianRed1")
                NitOpen() # Functions.py
                text.yview(END)
                time.sleep(1.5) # allow one second for testing
                global nitTimes
                nitTimes += 1
                print ('Allowed button press %d:3' % nitTimes)
                nitCloseAuto()
            else:
                print 'Maximum button presses (NIT) reached.\n\n\n\n\n'
                text.yview(END)
                
            
        def nitClose(event):
            buttonNT.configure(state = "normal", relief = "raised", bg = originalColor)
            NitClose() # Functions.py
            text.yview(END)

        def nitCloseAuto():
            buttonNT.configure(state = "normal", relief = "raised", bg = originalColor)
            NitClose() # Functions.py
            print "\n\n"
            text.yview(END)

        def aON(event): # alarm on
            saveColor(buttonAlarm)
            buttonAlarm.configure(state = "normal", relief = "raised", bg = "yellow2")
            alarmOn() # Functions.py
            print "Alarm ON\n\n\n\n\n"
            text.yview(END)
        def aOFF(event):
            buttonAlarm.configure(state = "normal", relief = "raised", bg = originalColor)
            alarmOff() # Functions.py
            print "Alarm OFF\n\n\n\n\n"
            text.yview(END)

        def waterON(event): # alarm on
            saveColor(button5)
            button5.configure(state = "normal", relief = "raised", bg = "aquamarine")
            waterOpen() # Functions.py
            print "Water Valve ON\n\n\n\n\n"
            text.yview(END)
        def waterOFF(event):
            button5.configure(state = "normal", relief = "raised", bg = originalColor)
            waterClose() # Functions.py
            print "Water Valve OFF\n\n\n\n\n"
            text.yview(END)

        

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Acid Hood Maintenance", font=('Times', 30))
        label.pack(pady=10, padx=10)
        
        label2 = tk.Label(self, text=" ", font=('Times', 10))
        label2.pack(pady=10)

        frame2 = tk.Frame(self)
        frame2.pack()

        button3 = tk.Button(frame2, text="Drain (TOGGLE)", width=20, height=4,
                            command=toggleDrain)
        button3.grid(row = 0, column = 0)

        button5 = tk.Button(frame2, text="Water Valve (MOMENTARY)", width=20, height=4)
        button5.bind("<Button-1>", waterON)
        button5.bind("<ButtonRelease-1>", waterOFF)
        button5.grid(row = 0, column = 1)

        buttonHF = tk.Button(frame2, text="HF Valve (Test)", width=20, height=4)
        buttonHF.bind("<Button-1>", hfOpen)
        buttonHF.grid(row = 1, column = 0)

        buttonNT = tk.Button(frame2, text="Nitric Valve (Test)", width=20, height=4)
        buttonNT.grid(row = 1, column = 1)
        buttonNT.bind("<Button-1>", nitOpen)

        buttonAlarm = tk.Button(frame2, text="Test Alarm (MOMENTARY)", width=20, height=4)
        buttonAlarm.bind("<Button-1>", aON)
        buttonAlarm.bind("<ButtonRelease-1>", aOFF)
        buttonAlarm.grid(row = 2, column = 0)

        button7 = tk.Button(frame2, text="ALL Sensor Status", width=20, height=4, command=getSensorStatus)
        button7.grid(row = 3, column = 0)

        button1 = tk.Button(frame2, text="Rinse", width=20, height=4,
                            fg = 'blue', command=rinseOnce)
        button1.grid(row = 2, column = 1)

        buttonC = tk.Button(frame2, text="Clear Text", width=20, height=4, command=clear)
        buttonC.grid(row = 3, column = 1)

        spacedLabel = Label(self, text = '  \n ', font = ('roman', 5)).pack()

        frame3 = tk.Frame(self)
        frame3.pack()

        

        button6 = tk.Button(frame3, text="Stop Operations", width=20, height=4,
                            fg = 'red', bg = 'yellow', command=stopOperations)
        button6.pack()
        
        button2 = tk.Button(frame3, text="Return", width = 20, height=4,
                           command=returnFrame)
        button2.pack()

        spacedLabel2 = Label(frame3, text = '  \n ', font = ('roman', 5)).pack()
        
        updateText()
        saveColor(button3) # set default button color
        checkDrainStatus()


# Leak Detected Frame
class LeakDetectedFrame(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)


        def silenceAlarm():
            print "Alarm OFF"
            text.yview(END)
            alarmOff() # leakThread.py
           
        def setCB(num):
            global cb
            if (num == 0):
                    cb = 0
            if (num == 1):
                    cb = 1
            else:
                    return
        
        def resetProg():            
            creds = 'User_Credentials.txt'
            def Login():
                global nameEL
                global pwordEL 
                global rootA
                rootA = Tk() 
                rootA.attributes('-topmost', 1)
                rootA.geometry('350x150+75+275')
                rootA.title('Verify Credentials') 
                intruction = Label(rootA, text='Enter Maintenance Credentials\n') 
                intruction.grid(sticky = E) 
                nameL = Label(rootA, text='Id: ')
                nameL.grid(row=1, sticky=W)
                nameEL = Entry(rootA) 
                nameEL.grid(row=1, column=1)
                loginB = Button(rootA, text='Verify', command=CheckLogin, height = 3, width = 15)
                loginB.grid(columnspan=2, sticky=W)
                rootA.mainloop()


            # Check wiether supervisor is logging in
            def checkSupervisor():
                with open(creds) as f:
                        data = f.read()
                        f.close()
                        if ("super:" + nameEL.get()) in data:
                            global isSupervisor
                            isSupervisor = 1
                        if("maintenance:" + nameEL.get()) in data:
                            global maintenanceUser
                            maintenanceUser = 1
                
            def CheckLogin():
                if (nameEL.get() == "dev"):
                    global currentUser
                    currentUser = nameEL.get()
                    rootA.destroy()
                    alarmOff() # leakThread.py
                    global yesMaintenance #stop thread from showing warning screen
                    yesMaintenance = 1
                    setCB(0) # sets control bit in leakThread.py to 0 and allows popup to be disabled
                    controller.show_frame(MaintenanceFrame)
                elif (nameEL.get() == ""):
                    text.yview(END)
                    print "Please enter credentials.\n\n\n\n"
                    text.yview(END)
                else:
                    checkSupervisor()
                    global isSupervisor
                    if (isSupervisor is 1 or maintenanceUser is 1):
                        global currentUser
                        currentUser = nameEL.get()
                        rootA.destroy()
                        alarmOff() # leakThread.py
                        setCB(0) # sets control bit to 0
                        global yesMaintenance #stop thread from showing warning screen
                        yesMaintenance = 1
                        controller.show_frame(MaintenanceFrame) # to maintenance Frame
                        
                        
                    else:
                            print "Maintenance privileges required to perform\noperation"
                            text.yview(END)
            Login() # check credentials
                
                
        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="ATTENTION\nMaintenance Required", font=('Times', 35))
        label.pack(pady=10, padx=10)

        if(GPIO.input(18) == 0):
            label2 = tk.Label(self, text="Leak Detected", font=('Times', 20))
            label2.pack(pady=10)
        else:
            label2 = tk.Label(self, text="Leak Detected", font=('Times', 20))
            label2.pack(pady=10)
            

        frame2 = tk.Frame(self)
        frame2.pack()

        button4 = tk.Button(frame2, text="Silence Alarm", width=30, height=10,
                            command=silenceAlarm)
        button4.grid(row = 0, column = 0)

        button3 = tk.Button(frame2, text="Return to Program", width=30, height=10,
                            command=resetProg)
        button3.grid(row = 1, column = 0)


# Overflow Detected Frame
class OverflowDetectedFrame(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)


        def silenceAlarm():
            print "Alarm OFF"
            text.yview(END)
            alarmOff() # leakThread.py
           
        def setCB(num):
            global cb
            if (num == 0):
                    cb = 0
            if (num == 1):
                    cb = 1
            else:
                    return
        
        def resetProg():            
            creds = 'User_Credentials.txt'
            def Login():
                global nameEL
                global pwordEL 
                global rootA
                rootA = Tk() 
                rootA.attributes('-topmost', 1)
                rootA.geometry('350x150+75+275')
                rootA.title('Verify Credentials') 
                intruction = Label(rootA, text='Enter Maintenance Credentials\n') 
                intruction.grid(sticky = E) 
                nameL = Label(rootA, text='Id: ')
                nameL.grid(row=1, sticky=W)
                nameEL = Entry(rootA) 
                nameEL.grid(row=1, column=1)
                loginB = Button(rootA, text='Verify', command=CheckLogin, height = 3, width = 15)
                loginB.grid(columnspan=2, sticky=W)
                rootA.mainloop()


            # Check wiether supervisor is logging in
            def checkSupervisor():
                with open(creds) as f:
                        data = f.read()
                        f.close()
                        if ("super:" + nameEL.get()) in data:
                            global isSupervisor
                            isSupervisor = 1
                        if("maintenance:" + nameEL.get()) in data:
                            global maintenanceUser
                            maintenanceUser = 1
                
            def CheckLogin():
                if (nameEL.get() == "dev"):
                    global currentUser
                    currentUser = nameEL.get()
                    rootA.destroy()
                    alarmOff() # leakThread.py
                    global yesMaintenance #stop thread from showing warning screen
                    yesMaintenance = 1
                    setCB(0) # sets control bit in leakThread.py to 0 and allows popup to be disabled
                    controller.show_frame(MaintenanceFrame)
                elif (nameEL.get() == ""):
                    text.yview(END)
                    print "Please enter credentials.\n\n\n\n"
                    text.yview(END)
                else:
                    checkSupervisor()
                    global isSupervisor
                    if (isSupervisor is 1 or maintenanceUser is 1):
                        global currentUser
                        currentUser = nameEL.get()
                        rootA.destroy()
                        alarmOff() # leakThread.py
                        setCB(0) # sets control bit to 0
                        global yesMaintenance #stop thread from showing warning screen
                        yesMaintenance = 1
                        controller.show_frame(MaintenanceFrame) # to maintenance Frame
                        
                        
                    else:
                            print "Maintenance privileges required to perform\noperation"
                            text.yview(END)
            Login() # check credentials
                
                
        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="ATTENTION\nMaintenance Required", font=('Times', 35))
        label.pack(pady=10, padx=10)

        if(GPIO.input(18) == 0):
            label2 = tk.Label(self, text="Leak Detected", font=('Times', 20))
            label2.pack(pady=10)
        else:
            label2 = tk.Label(self, text="Overflow Detected", font=('Times', 20))
            label2.pack(pady=10)
            

        frame2 = tk.Frame(self)
        frame2.pack()

        button4 = tk.Button(frame2, text="Silence Alarm", width=30, height=10,
                            command=silenceAlarm)
        button4.grid(row = 0, column = 0)

        button3 = tk.Button(frame2, text="Return to Program", width=30, height=10,
                            command=resetProg)
        button3.grid(row = 1, column = 0)


# Interlock Frame
class InterlockFrame(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)


        def silenceAlarm():
            print "Alarm OFF"
            text.yview(END)
            alarmOff() # leakThread.py
           
        def setCB(num):
            global cb
            if (num == 0):
                    cb = 0
            if (num == 1):
                    cb = 1
            else:
                    return
        
        def resetProg():            
            creds = 'User_Credentials.txt'
            def Login():
                global nameEL
                global pwordEL 
                global rootA
                rootA = Tk() 
                rootA.attributes('-topmost', 1)
                rootA.geometry('350x150+75+275')
                rootA.title('Verify Credentials') 
                intruction = Label(rootA, text='Enter Maintenance Credentials\n') 
                intruction.grid(sticky = E) 
                nameL = Label(rootA, text='Id: ')
                nameL.grid(row=1, sticky=W)
                nameEL = Entry(rootA) 
                nameEL.grid(row=1, column=1)
                loginB = Button(rootA, text='Verify', command=CheckLogin, height = 3, width = 15)
                loginB.grid(columnspan=2, sticky=W)
                rootA.mainloop()


            # Check wiether supervisor is logging in
            def checkSupervisor():
                with open(creds) as f:
                        data = f.read()
                        f.close()
                        if ("super:" + nameEL.get()) in data:
                            global isSupervisor
                            isSupervisor = 1
                        if("maintenance:" + nameEL.get()) in data:
                            global maintenanceUser
                            maintenanceUser = 1
                
            def CheckLogin():
                if (nameEL.get() == "dev"):
                    global currentUser
                    currentUser = nameEL.get()
                    rootA.destroy()
                    alarmOff() # leakThread.py
                    global yesMaintenance #stop thread from showing warning screen
                    yesMaintenance = 1
                    setCB(0) # sets control bit in leakThread.py to 0 and allows popup to be disabled
                    controller.show_frame(MaintenanceFrame)
                elif (nameEL.get() == ""):
                    text.yview(END)
                    print "Please enter credentials.\n\n\n\n"
                    text.yview(END)
                else:
                    checkSupervisor()
                    global isSupervisor
                    if (isSupervisor is 1 or maintenanceUser is 1):
                        global currentUser
                        currentUser = nameEL.get()
                        rootA.destroy()
                        alarmOff() # leakThread.py
                        setCB(0) # sets control bit to 0
                        global yesMaintenance #stop thread from showing warning screen
                        yesMaintenance = 1
                        controller.show_frame(MaintenanceFrame) # to maintenance Frame
                        
                        
                    else:
                            print "Maintenance privileges required to perform\noperation"
                            text.yview(END)
            Login() # check credentials
                
                
        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="ATTENTION\nMaintenance Required", font=('Times', 35))
        label.pack(pady=10, padx=10)
        
        label2 = tk.Label(self, text="Interlock Opened", font=('Times', 20))
        label2.pack(pady=10)
            

        frame2 = tk.Frame(self)
        frame2.pack()

        button4 = tk.Button(frame2, text="Silence Alarm", width=30, height=10,
                            command=silenceAlarm)
        button4.grid(row = 0, column = 0)

        button3 = tk.Button(frame2, text="Return to Program", width=30, height=10,
                            command=resetProg)
        button3.grid(row = 1, column = 0)

      
# FillV Processing Frame           
class toFillVFrame(tk.Frame):
    def __init__(self, parent, controller):

        global sec
        global go
        global secW
        global secHF
        global secHN
        global goNH
        global currentSec
        global state
        global warning
        warning = 0

        #initializing global fill permission variables so multiples fills can't start
        global fw1
        global fw2
        global fw3
        global fwV
        fw1 = 0
        fw2 = 0
        fw3 = 0
        fwV = 0

        
         # Timer to display seconds   
        def tick():
            global go
            global sec
            global currentSec
            global newWaterTime
            global saveNH
            global saveHF
            global saveWater
            global state
            global fillOption #controls which tickW, tickHF, tickNH to use form inside tick()
            global mayProceed

            n2ON() # turn on the N2 Curtain
            
            
            def pause():
                print"Paused, Hold Deadman switch to resume"
                print "Warning, failing to hold dead man switch again will result in auto-drain and rinse."
                global autoNumberTimesLeft
                autoNumberTimesLeft = 3
                global functionCalled
                functionCalled = "DeadMan Switch Released, System paused."
                logFunction(currentUser, functionCalled)
                

                def autoDrainRinse(): # function to automatically drain and rinse as penalty for not holding dmain switch
                    global y
                    y = drainTime
                    global z
                    z = rinseTime
                    
                    def autoDrain():
                        if GPIO.input(18) == 0 or GPIO.input(22) == 0 or alreadyOperating == 0:
                            try:
                                global rootB
                                rootB.destroy()
                            except:
                                pass
                            tickReset()
                            stop()
                            if(GPIO.input(22) == 0):
                                openDrain()
                        else:
                            drain()
                            text.yview(END)
                            if y == 0:
                                autoRinse()
                            if y <= drainTime and not y == 0:
                                global y
                                print ("Total seconds remaining to drain: %s\ncurrent round: %s\n\n\n" %(y, autoNumberTimesLeft))
                                y -= 1
                                text.yview(END)
                                time.after(1000, autoDrain)
                    def autoRinse():
                        if GPIO.input(18) == 0 or GPIO.input(22) == 0 or alreadyOperating == 0: #dripSensors check
                            try:
                                global rootB
                                rootB.destroy()
                            except:
                                pass
                            tickReset()
                            stop()
                            if(GPIO.input(22) == 0):
                                openDrain()
                        else:
                            rinse()
                            if z == 0:
                                global autoNumberTimesLeft
                                autoNumberTimesLeft -= 1
                                time.after(1000, autoDrainRinse)
                            if z == 0 and autoNumberTimesLeft == 0: # this works appropriately
                                stop()
                                drain()
                                print"Final drain commencing"
                                global allowNoStop
                                allowNoStop = 0
                                text.yview(END)
                                try:
                                    global rootB
                                    rootB.destroy()
                                except:
                                    pass
                            if z >=1:
                                global z
                                print ("Total seconds remaining to rinse: %s\ncurrent round: %s\n\n\n" %(z, autoNumberTimesLeft))
                                z -= 1
                                text.yview(END)
                                time.after(1000, autoRinse)

                    if autoNumberTimesLeft > 0:
                        stop() #make sure everything is off before opening more valves
                        autoDrain()
                    
                            
                def count():
                    text.yview(END)
                    refreshGui()
                    if GPIO.input(18) == 0 or GPIO.input(22) == 0: #dripSensors
                        try:
                            global rootB
                            rootB.destroy()
                            tickReset()
                            if(GPIO.input(22) == 0):
                                openDrain()
                        except:
                            pass
                    elif GPIO.input(32) == 0: # once deadman is detected again
                        if GPIO.input(18) == 0 or GPIO.input(22) == 0: #dripSensors
                            global rootB
                            rootB.destroy()
                            tickReset()
                            if(GPIO.input(22) == 0):
                                openDrain()
                        if  mayProceed == 1:
                            global warning
                            warning = 1
                            warningMessage() #warning popup at 5 seconds
                            global x
                            x = 1
                            return
                        elif GPIO.input(18) == 1:
                            global x
                            print ("Total seconds paused: %s" %x)
                            x += 1
                            text.yview(END)
                            refreshGui()
                            time.after(1000, count)
                        else:
                            return

                    elif x >= penaltyTime: #x amount of seconds before auto rinse for penalty
                        global alreadyOperating
                        alreadyOperating == 1
                        if GPIO.input(32) == 1: #while no deadman switch is detected
                            global functionCalled
                            functionCalled = "Drain/Rinse Penalty"
                            logFunction(currentUser, functionCalled)
                            autoDrainRinse()
                                    
                    elif GPIO.input(32) == 1:
                        global x
                        print ("Total seconds paused: %s" %x) #only one that actually prints anything....
                        x += 1
                        #text.yview(END)
                        time.after(1000, count)

                def refusal():
                    text.yview(END)
                    print"Cannot delete window, must press\nresume with DeadMan"
                    text.yview(END)

                def checkState():
                    if state == 1:
                        intruction = Label(rootB, text='Paused during ***WATER***\n%d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                           font=('Times', 25), bg ='red') 
                        intruction.pack()
                        
                    if state == 2:
                        intruction = Label(rootB, text='Paused during ***HF***\n%d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                           font=('Times', 25), bg ='red') 
                        intruction.pack()

                    if state == 3:
                        intruction = Label(rootB, text='Paused during ***NHO3***\n%d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                           font=('Times', 25), bg ='red') 
                        intruction.pack()

                    if state == 4:
                        intruction = Label(rootB, text='Paused during ***FINAL WATER***\n%d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                           font=('Times', 25), bg ='red') 
                        intruction.pack()
                        
                    count() # timer that counts up for dead man pause

  
                global rootB # window for when do deadman switch is detected
                global sec
                global state
                rootB = Tk()
                rootB.attributes('-topmost', 1)
                rootB.overrideredirect(True)
                rootB.geometry("500x640")# Window dimensions(w x h + starting w + starting h)
                rootB.resizable(0, 0) # cannot resize window
                rootB.config(bg='red')
                rootB.title('No Deadman Signal Detected')
                spaceLabel = Label(rootB, text=' \nWARNING\n ', font=('Times', 50), bg ='red') 
                spaceLabel.pack()
                intruction = Label(rootB, text='Press resume to continue', font=('Times', 25), bg ='red') 
                intruction.pack()
                resumeB = Button(rootB, text='Resume', height = 8, width = 25, command=resumeState) 
                resumeB.pack()
                checkState()
                             
                
            def resumeState():
                if mayProceed == 1: # bug fix for when alarm and deadMan screen both activate
                    global rootB
                    rootB.destroy()
                    global allowNoStop # control bit to allow stop autoDrainRinse
                    allowNoStop = 0
                    
                if (GPIO.input(32) == 0 and mayProceed == 0):
                    global rootB
                    rootB.destroy()
                    global mayProceed # gets you out of the dman screen counter
                    mayProceed = 1
                    global functionCalled
                    functionCalled = "Resumed Operation"
                    logFunction(currentUser, functionCalled)
                    if state == 1:
                        fillWater() # Functions.py
                        tick() # Functions.py
                        print "Resuming Water\n"
                        text.yview(END)
                    if state == 2:
                        HFfill() # Functions.py
                        waterOpen() # Functions.py
                        print "Resuming HF\n"
                        text.yview(END)
                        tick()
                    if state == 3:
                        NHfill() # Functions.py
                        waterOpen() # Functions.py
                        print "Resuming NHO3\n"
                        text.yview(END)
                        tick()
                    if state == 4:
                        waterOpen() # functions.py
                        print "Resuming Final Water\n"
                        text.yview(END)
                        tick()
                    '''if warning == 1 and x >= 5: #setting x for dman timeout second time
                        finishTimer()
                        global alreadyOperating
                        alreadyOperating = 1
                        global allowNoStop # control bit to not allow stop button to stop autoDrainRinse
                        allowNoStop = 1'''
                    
                if GPIO.input(32) == 1:
                    print "Hold DeadMan and press resume"
                    text.yview(END)

                    
                


            if GPIO.input(32) == 1: #changed to GPIO.input(32) == 1
                global saveSec
                saveSec = sec
                stop()
                global x
                x = 0
                global mayProceed
                mayProceed = 0
                pause()
                     
            
             #Tick Continuation   
            if sec > 0 and GPIO.input(32) == 0:
                global sec
                sec -= 1
                time['text'] = sec

                if GPIO.input(18) == 0 or GPIO.input(22) == 0: #dripSensors
                    stop()
                    tickReset()
                    if(GPIO.input(22) == 0):
                        openDrain()
                
                # Start Water Tick
                if sec > 0 and go == 1 and goHF == 0 and goNH == 0 and  goFW == 0 and GPIO.input(32) == 0:
                    if GPIO.input(32) == 0:
                        time.after(1000, tick)
                        print ("Water Time Left: %s\n" %sec)
                        global state
                        state = 1
                        text.yview(END)
                        return sec

                #HF Tick
                if sec > 0 and go == 1 and goHF == 1 and goNH == 0 and goFW == 0 and GPIO.input(32) == 0:
                    if GPIO.input(32) == 0:
                        time.after(1000, tick)
                        print ("HF Time Left: %s\n\n\n" %sec)
                        global state
                        state = 2
                        text.yview(END)
                        return sec

                #NHO3 Tick
                if sec > 0 and go == 1 and goHF == 1 and goNH == 1 and goFW == 0 and GPIO.input(32) == 0:
                    if GPIO.input(32) == 0:
                        time.after(1000, tick)
                        print ("NHO3 Time Left: %s\n\n\n" %sec)
                        global state
                        state = 3
                        text.yview(END)
                        return sec

                #Final Water Tick
                if sec > 0 and go == 1 and goHF == 1 and goNH == 1 and goFW == 1 and GPIO.input(32) == 0:
                    if GPIO.input(32) == 0:
                        time.after(1000, tick)
                        print ("Water Time Left: %s\n\n\n" %sec)
                        global state
                        state = 4
                        text.yview(END)
                        return sec

                #Start HF Timer
                if sec == 0 and go == 1 and goHF == 0 and goNH == 0 and goFW == 0 and GPIO.input(32) == 0:
                    time['text'] = sec
                    stop()
                    waterOpen() # turns water valve back on, functions.py
                    
                    
                    if fillOption is 1:
                        print ("Starting HF Timer: %s seconds." % newHFTime)
                        text.yview(END)
                        tickHF()
                        return sec

                    if fillOption is 2:
                        print ("Starting HF Timer: %s seconds." % newHFTime_Fill2)
                        text.yview(END)
                        tickHF2()
                        return sec

                    if fillOption is 3:
                        print ("Starting HF Timer: %s seconds." % newHFTime_Fill3)
                        text.yview(END)
                        tickHF3()
                        return sec

                    if fillOption is 4:
                        print ("Starting HF Timer: %s seconds." % newHFTime_Fill_Variable)
                        text.yview(END)
                        tickHFV()
                        return sec

                #Start NHO3 Timer
                if sec == 0 and goHF == 1 and goNH == 0 and go == 1 and GPIO.input(32) == 0:
                    global saveNH
                    global saveHF
                    global saveWater
                    saveHF = 0
                    saveNH = 1
                    saveWater = 0
                    
                    time['text'] = sec
                    stop()
                    waterOpen() # turns water valve back on, functions.py
                    print "HF Complete"
                    text.yview(END)
                    
                    print ("Starting HNO3 Timer: %s seconds." % newHNTime)
                    text.yview(END)

                    if fillOption is 1:
                        tickNH()
                        print"tickNH"
                        text.yview(END)
                        return sec

                    if fillOption is 2:
                        tickNH2()
                        print"tickNH2"
                        text.yview(END)
                        return sec

                    if fillOption is 3:
                        tickNH3()
                        print"tickNH3"
                        text.yview(END)
                        return sec

                    if fillOption is 4:
                        tickNHV()
                        print"tickNHV"
                        text.yview(END)
                        return sec
                        
                #Start Final Water Timer
                if sec == 0 and goHF == 1 and goNH == 1 and go == 1 and goFW == 0 and GPIO.input(32) == 0:
                    global saveNH
                    global saveHF
                    global saveWater
                    saveHF = 0
                    saveNH = 1
                    saveWater = 0
                    
                    time['text'] = sec
                    stop()
                    waterOpen() # turns water valve back on, functions.py
                    print "NHO3 Complete"
                    text.yview(END)
                    

                    if fillOption is 1:
                        tickFW(newWaterFinishTime)
                        print"Final Water Fill"
                        text.yview(END)
                        return sec

                    if fillOption is 2:
                        tickFW(newWaterFinishTime_Fill2)
                        print"Final Water Fill2"
                        text.yview(END)
                        return sec

                    if fillOption is 3:
                        tickFW(newWaterFinishTime_Fill3)
                        print"Final Water Fill3"
                        text.yview(END)
                        return sec

                    if fillOption is 4:
                        tickFW(newWaterFinishTime_FillV)
                        print"Final Water FillV"
                        text.yview(END)
                        return sec
                    
                #Hold Timer
                if sec == 0 and goHF == 1 and goNH == 1 and go == 1 and goFW == 1 and (GPIO.input(32) == 0 or GPIO.input(32) == 1):
                    global sec
                    global functionCalled
                    
                    functionCalled = "Holding Acid Solution"
                    logFunction(currentUser, functionCalled)
                    def holdTime(holdSec):
                        allLow() # hold solution, all gpio low to hold liquid
                        text.yview(END)
                        global secz
                        secz = holdSec

                        def autoDrainRinse(): # function to automatically drain and rinse as penalty for not holding dmain switch
                                global y
                                y = drainTime
                                global z
                                z = rinseTime
                                
                                def autoDrain():
                                    if GPIO.input(18) == 0 or GPIO.input(22) == 0 or alreadyOperating == 0: #dripSensors check
                                        try:
                                            global rootB
                                            rootB.destroy()
                                        except:
                                            pass
                                        tickReset()
                                        stop()
                                        if(GPIO.input(22) == 0):
                                            openDrain()
                                    else:
                                        print "inside of autoDrain"
                                        drain()
                                        text.yview(END)
                                        if y == 0:
                                            autoRinse()
                                        if y <= drainTime and not y == 0:
                                            global y
                                            print ("Total seconds remaining to drain: %s\ncurrent round: %s" %(y, autoNumberTimesLeft))
                                            y -= 1
                                            text.yview(END)
                                            time.after(1000, autoDrain)
                                def autoRinse():

                                    if (GPIO.input(18) == 0 or GPIO.input(22) == 0 or alreadyOperating == 0): #dripSensors check
                                        try:
                                             global rootB
                                             rootB.destroy()
                                        except:
                                            pass
                                        tickReset()
                                        stop()
                                        if(GPIO.input(22) == 0):
                                            openDrain()
                                    else:
                                        print "inside of autoRinse"
                                        text.yview(END)
                                        rinse()
                                        if z == 0:
                                            global autoNumberTimesLeft
                                            autoNumberTimesLeft -= 1
                                            time.after(1000, autoDrainRinse)
                                        if z == 0 and autoNumberTimesLeft == 0: # this works appropriately
                                            stop()
                                            drain()
                                            print"Final drain commencing"
                                            global allowNoStop
                                            allowNoStop = 0
                                            text.yview(END);
                                            
                                        if z >=1:
                                            global z
                                            print ("Total seconds remaining to rinse: %s\ncurrent round: %s" %(z, autoNumberTimesLeft))
                                            z -= 1
                                            text.yview(END)
                                            time.after(1000, autoRinse)

                                if autoNumberTimesLeft > 0:
                                    stop() #make sure everything is off before opening more valves
                                    autoDrain()
                                    
                        def keepHolding():

                            if (GPIO.input(18) == 0 or GPIO.input(22) == 0 or alreadyOperating == 0): #dripSensors check
                                try:
                                     global rootB
                                     rootB.destroy()
                                except:
                                    pass
                                tickReset()
                                stop()
                                if(GPIO.input(22) == 0):
                                    openDrain()
                            if secz == 0:
                                    print "Holding Complete, proceeding to autoDrainRinse.\n"
                                    text.yview(END)
                                    global autoNumberTimesLeft
                                    autoNumberTimesLeft = 5
                                    autoDrainRinse()
                                    print "after autoDrai nRinse"
                                    ##drain()####################
                            if secz <= holdSec and not secz == 0 and go == 1:
                                
                                global secz
                                text.yview(END)
                                print ("Holding for: %s seconds before draining.\n\n\n\n" %secz)
                                secz -= 1
                                time.after(1000, keepHolding)

                            
                        keepHolding()
                        
                    global holdSecFill
                    holdTime(holdSecFill) #make sure assignments are woking for holdSecFill, change back
         
        #finish timer
        def finishTimer():
            text.yview(END)
            global fillOption
            fillOption = 0
            text.yview(END)
            global alreadyOperating
            alreadyOperating = 0
            global warning
            warning = 0
            global fw1
            global fw2
            global fw3
            global fwV
            fw1 = 0
            fw2 = 0
            fw3 = 0
            fwV = 0
            tickReset()
            functionCalled = "Filling Completed Successfully"
            logFunction(currentUser, functionCalled)
            #resetTimeout()
                
        # Reset Timer
        def tickReset():
            global sec
            sec = 0
            global go
            go = 0
            global x # reset DeadMan Timer
            x = -1
            time['text'] = sec
            print "Timer reset."
            text.yview(END)
            global warning
            warning = 0

        # Start Water Timer
        def tickW():
            if (fw1 and not(fw2 or fw3 or fwV) and alreadyOperating == 0):
                global go
                global newWaterTime
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFill1
                alreadyOperating = 1
                fillOption = 1
                go = 1
                sec = newWaterTime
                goNH = 0
                goHF = 0
                goFW = 0
                #fillWater is defined on fill_proc event
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"

        # Start HF Timer
        def tickHF():
            if (fw1 and not(fw2 or fw3 or fwV)):
                global go
                global newHFTime
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime
                HFfill()
                tick()

        #Start NHO3 Timer
        def tickNH():
            if (fw1 and not(fw2 or fw3 or fwV)):
                global go
                global newHNTime
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime
                NHfill()
                tick()

        #Start Final Water Timer
        def tickFW(duration): #todo duration
            global go
            global sec
            global goFW
            goFW = 1
            go = 1
            sec = duration # TODO
            waterOpen() # functions.py
            tick()

            # Start Water Timer 2
        def tickW2():
            if (fw2 and not(fw1 or fw3 or fwV)and alreadyOperating == 0):
                global go
                global newWaterTime_Fill2
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFill2
                alreadyOperating = 1
                fillOption = 2
                go = 1
                sec = newWaterTime_Fill2
                goNH = 0
                goHF = 0
                goFW = 0
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"    

        # Start HF Timer 2
        def tickHF2():
            if (fw2 and not(fw1 or fw3 or fwV)):
                global go
                global newHFTime_Fill2
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime_Fill2
                HFfill()
                tick()

        #Start NHO3 Timer 2
        def tickNH2():
            if (fw2 and not(fw1 or fw3 or fwV)):
                global go
                global newHNTime_Fill2
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime_Fill2
                NHfill()
                tick()


        # Start Water Timer 3
        def tickW3():
            if (fw3 and not(fw1 or fw2 or fwV)and alreadyOperating == 0):
                global go
                global newWaterTime_Fill3
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFill3
                alreadyOperating = 1
                fillOption = 3
                go = 1
                sec = newWaterTime_Fill3
                goNH = 0
                goHF = 0
                goFW = 0
                #fiillWater is defined on fill_proc event
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"

       

        # Start HF Timer 3
        def tickHF3():
            if (fw3 and not(fw1 or fw2 or fwV)):
                global go
                global newHFTime_Fill3
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime_Fill3
                HFfill()
                tick()

        #Start NHO3 Timer 3
        def tickNH3():
            if (fw3 and not(fw1 or fw2 or fwV)):
                global go
                global newHNTime_Fill3
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime_Fill3
                NHfill()
                tick()


        # Start Water Timer V
        def tickWV():
            if (fwV and not(fw1 or fw2 or fw3) and (superUser == 1 or isSupervisor == 1)):
                global go
                global newWaterTime_Fill_Variable
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFillV
                alreadyOperating = 1
                fillOption = 4
                go = 1
                sec = newWaterTime_Fill_Variable
                goNH = 0
                goHF = 0
                goFW = 0
                #fiillWater is defined on fill_proc event
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"

       

        # Start HF Timer V
        def tickHFV():
            if (fwV and not(fw1 or fw2 or fw3)):
                global go
                global newHFTime_Fill_Variable
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime_Fill_Variable
                HFfill()
                tick()

        #Start NHO3 Timer V
        def tickNHV():
            if (fwV and not(fw1 or fw2 or fw3)):
                global go
                global newHNTime_Fill_Variable
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime_Fill_Variable
                NHfill()
                tick()


        # Check to see if fill of any type is already in operation
        def isOperating():
            if fw1 and not(fw2 or fw3 or fwV):
                global currentFill
                currentFill = "Fill 1"
                print ("%s already in operation!" % currentFill)
            if fw2 and not(fw1 or fw3 or fwV):
                global currentFill
                currentFill = "Fill 2"
                print ("%s already in operation!" % currentFill)
            if fw3 and not(fw2 or fw1 or fwV):
                global currentFill
                currentFill = "Fill 3"
                print ("%s already in operation!" % currentFill)
            if fwV and not(fw2 or fw3 or fw1):
                global currentFill
                currentFill = "Fill V"
                print ("%s already in operation!" % currentFill)
                
           
        # Event Functions
        def wait():
            global fillNum
            print 'Waiting for user to press DeadMan'
            text.yview(END)

            if (stopPressed): # if user presses stop
                print "\n\n\n\n\n\n"
                text.yview(END)
                return
                
            elif (GPIO.input(32) == 0):
                print 'DeadMan detected, proceeding . . .'
                text.yview(END)
                if fillNum == 1:
                    fillproc_event_single()
                if fillNum == 2:
                    fillproc_event_single2()
                if fillNum == 3:
                    fillproc_event_single3()
                if fillNum == 4:
                    fillproc_event_singleV()
                
            else:
                time.after(500, wait)

                            
        def fillproc_event(event):
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 1
                    global stopPressed
                    stopPressed = False
                    wait()
                else:  
                    global functionCalled
                    functionCalled = "Fill 1"
                    logFunction(currentUser, functionCalled)
                    global fw1
                    fw1 = 1
                    fillWater() #Function.py
                    resetTimeout()
                    tickW()

            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_single(): ## test
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 1
                    wait()
                else:  
                    global functionCalled
                    functionCalled = "Fill 1"
                    logFunction(currentUser, functionCalled)
                    global fw1
                    fw1 = 1
                    fillWater() #Function.py
                    resetTimeout()
                    tickW()

            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event2(event):
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 2
                    global stopPressed
                    stopPressed = False
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 2"
                    logFunction(currentUser, functionCalled)
                    global fw2
                    fw2 = 1
                    fillWater() #Function.py
                    tickW2()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_single2():
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 2
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 2"
                    logFunction(currentUser, functionCalled)
                    global fw2
                    fw2 = 1
                    fillWater() #Function.py
                    tickW2()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event3(event):
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 3
                    global stopPressed
                    stopPressed = False
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 3"
                    logFunction(currentUser, functionCalled)
                    global fw3
                    fw3 = 1
                    fillWater() #Function.py
                    tickW3()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_single3():
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 3
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 3"
                    logFunction(currentUser, functionCalled)
                    global fw3
                    fw3 = 1
                    fillWater() #Function.py
                    tickW3()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_eventV(event):
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 4
                    global stopPressed
                    stopPressed = False
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill V"
                    logFunction(currentUser, functionCalled)
                    global fwV
                    fwV = 1
                    fillWater() #Function.py
                    tickWV()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_singleV():
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 4
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill V"
                    logFunction(currentUser, functionCalled)
                    global fwV
                    fwV = 1
                    fillWater() #Function.py
                    tickWV()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        # Event Functions
        def stop_event(event):
            if allowNoStop == 0:
                stop()
                tickReset()
                print("Stopped.")
                text.yview(END)
                global functionCalled
                functionCalled = "STOP"

                try:
                    logFunction(currentUser, functionCalled) # gets rid of bug where no user click emo and won't be recorded
                except:
                    pass
                
                global alreadyOperating
                alreadyOperating = 0
                global fw1
                global fw2
                global fw3
                global fwV
                fw1 = 0
                fw2 = 0
                fw3 = 0
                fwV = 0

                if (alreadyOperating is 0):
                    n2OFF()
           
        def nextRecipe_event(event):
            if alreadyOperating == 1:
                 print ("Recipe must finish!")
                 text.yview(END)
            else:
                stop()
                tickReset()
                print("Ready for next recipe.")
                text.yview(END)
                global functionCalled
                functionCalled = "STOP"

                try:
                    logFunction(currentUser, functionCalled) # gets rid of bug where no user click emo and won't be recorded
                except:
                    pass

                global alreadyOperating
                alreadyOperating = 0
                global fw1
                global fw2
                global fw3
                global fwV
                fw1 = 0
                fw2 = 0
                fw3 = 0
                fwV = 0

                global currentProcess
                currentProcess = 'Ready'
                processLabel['text'] = currentProcess

        def resume_event(event):
            print("Resuming Operation")
            text.yview(END)

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

            def clear(self):
                text.delete(0, END)

        def clear():
            print "\n\n\n\n\n\n\n"
            text.yview(END)

        def threadLogout():
            controller.show_frame(MainMenu)
            timeoutLogoutUser(currentUser) #record when which user logs out
            print "Session timed out . . ."
            text.yview(END)
            global superUser
            superUser = 0
            global isSupervisor # sets supervisor control bit back to 0
            isSupervisor = 0

        def allowLogout(event): #check to see if anything is in operation before allowing user to logout
            if (alreadyOperating == 0):
                clear() #clear text entry
                controller.show_frame(MainMenu)
                print "Successfully logged out"
                try:
                    t.cancel() # cancel if thread is started for normal user
                except:
                    pass
                    
                text.yview(END)
                logoutUser(currentUser) #record when which user logs out
                global superUser
                superUser = 0
                #restart_program() # called from functions.py
                global isSupervisor # sets supervisor control bit back to 0
                isSupervisor = 0
            else:
                print "Operation must finish!"
                text.yview(END)

        def promptDrain(event): # if only one click is applied to drain button
            print "Double-click to start drain"
            text.yview(END)

        def startDrain(event): #event to start draining
            if (alreadyOperating == 0):
                print "starting drain"
                global functionCalled
                functionCalled = "Drain"
                logFunction(currentUser, functionCalled)
                text.yview(END)
                drain()
                resetTimeout()
            else:
                print "Operation must finish!"
                text.yview(END)

        def resetTimeout():
            global t
            try:
                t.cancel()
            except:
                pass
            global timeoutTime
            t = Timer(timeoutTime, threadLogout) # change to 3600 seconds for 1 hr
            t.start()


        def timeOut(event):
           global ts


        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        
        label = tk.Label(self, text="Fill Variable Menu", font=('Times', 40))
        label.pack()

        label2 = tk.Label(self, text=" ", font=('Times', 20))
        label2.pack()

        frame4 = tk.Frame(self)
        frame4.pack(anchor = N, side = TOP)
        
        
        time = Label(frame4, fg='red', font =("Courier", 30) )
        time.pack(side = RIGHT, anchor = NE)
        tk.Label(frame4, fg='blue', text='Fill Timer: ', font =("Courier", 30)).pack(anchor = NE)

        frame2=tk.Frame(self) # third frame next to middle frame
        frame2.bind(not "<Button-1>", timeOut)
        frame2.pack(anchor = N)


        buttonf4 = tk.Button(frame2, text="Recipe (Variable)", height=5, width=20)
        buttonf4.bind("<Button-1>", fillproc_eventV)
        buttonf4.pack()


        buttonD = tk.Button(frame2, text="Drain", height=6, width=20)
        buttonD.bind('<Button-1>', promptDrain)
        buttonD.bind('<Double-Button-1>', startDrain)
        buttonD.pack()
        
        buttonC = tk.Button(frame2, text="Clear", height=6, width=20,
                            command=clear)
        buttonC.pack()

        button8 = tk.Button(frame2, text="Return", height=6, width=20, command = lambda:controller.show_frame(OptionFrame))
        button8.pack()

        spaceLabel = tk.Label(frame2, text="",
                            font=('Times', 8), width = 15).pack()# spot for graphic, add pic somehow

        
        button3 = tk.Button(frame2, text="E-STOP", height=3, width=15, bg = "red", fg = "black", font = ("Times", 10, "bold")) #frame2 instead of self for position inside of frame 2
        button3.bind("<Button-1>", stop_event)
        button3.pack()


# Fill Processing Frame           
class FillProcMenu(tk.Frame):
    def __init__(self, parent, controller):

        global sec
        global go
        global secW
        global secHF
        global secHN
        global goNH
        global currentSec
        global state
        global warning
        warning = 0

        #initializing global fill permission variables so multiples fills can't start
        global fw1
        global fw2
        global fw3
        global fw4
        global fw5
        global fw6
        global fwV
        fw1 = 0
        fw2 = 0
        fw3 = 0
        fw4 = 0
        fw5 = 0
        fw6 = 0
        fwV = 0
        
         # Timer to display seconds   
        def tick():
            global go
            global sec
            global currentSec
            global newWaterTime
            global saveNH
            global saveHF
            global saveWater
            global state
            global fillOption #controls which tickW, tickHF, tickNH to use form inside tick()
            global mayProceed

            n2ON() # Activate the N2 curtain.
            
            # pause function when user let's go of deadman switch when filling during recipe
            def pause():
                print"Paused, Hold Deadman switch to resume"
                print "Warning, failing to hold dead man switch again will result in auto-drain and rinse."
                global autoNumberTimesLeft
                autoNumberTimesLeft = 3
                global functionCalled
                functionCalled = "DeadMan Switch Released, System paused."
                logFunction(currentUser, functionCalled)
                

                def autoDrainRinse(): # function to automatically drain and rinse as penalty for not holding dmain switch
                    global y
                    y = drainTime
                    global z
                    z = rinseTime

                    try:
                        intruction['text'] = 'Drain/Rinse in Operation.\nExit upon Completion.\n\n'
                        refreshGui()
                    except:
                        pass
                    try:
                        resumeB.destroy()
                    except:
                        pass
                    
                    def autoDrain():
                        if GPIO.input(18) == 0 or GPIO.input(22) == 0:
                            try:
                                global rootB
                                rootB.destroy()
                            except:
                                pass
                            tickReset()
                            stop()
                            if(GPIO.input(22) == 0):
                                openDrain()
                        else:
                            drain()
                            text.yview(END)
                            if y == 0:
                                autoRinse()
                            if y <= drainTime and not y == 0:
                                global y
                                print ("Total seconds remaining to drain: %s\ncurrent round: %s\n\n\n" %(y, autoNumberTimesLeft))
                                y -= 1
                                text.yview(END)
                                time.after(1000, autoDrain)
                    def autoRinse():
                        if GPIO.input(18) == 0 or GPIO.input(22) == 0: #dripSensors check
                            try:
                                global rootB
                                rootB.destroy()
                            except:
                                pass
                            tickReset()
                            stop()
                            if(GPIO.input(22) == 0):
                                openDrain()
                        else:
                            rinse()
                            if z == 0:
                                global autoNumberTimesLeft
                                autoNumberTimesLeft -= 1
                                time.after(1000, autoDrainRinse)
                            if z == 0 and autoNumberTimesLeft == 0: # this works appropriately
                                stop()
                                drain()
                                print"Final drain commencing"
                                global allowNoStop
                                allowNoStop = 0
                                text.yview(END)
                                try:
                                    global rootB
                                    rootB.destroy()
                                except:
                                    pass
                            if z >=1:
                                global z
                                print ("Total seconds remaining to rinse: %s\ncurrent round: %s\n\n\n" %(z, autoNumberTimesLeft))
                                z -= 1
                                text.yview(END)
                                time.after(1000, autoRinse)

                    if autoNumberTimesLeft > 0:
                        stop() #make sure everything is off before opening more valves
                        autoDrain()
                        global alreadyOperating
                        alreadyOperating = 0
                    
                            
                def count():
                    text.yview(END)
                    refreshGui()
                    if GPIO.input(18) == 0 or GPIO.input(22) == 0: #dripSensors
                        try:
                            global rootB
                            rootB.destroy()
                            tickReset()
                            if(GPIO.input(22) == 0):
                                openDrain()
                        except:
                            pass
                    elif GPIO.input(32) == 0: # once deadman is detected again
                        if GPIO.input(18) == 0 or GPIO.input(22) == 0: #dripSensors
                            global rootB
                            rootB.destroy()
                            tickReset()
                            if(GPIO.input(22) == 0):
                                openDrain()
                        if  mayProceed == 1:
                            global warning
                            warning = 1
                            warningMessage() #warning popup at 5 seconds
                            global x
                            x = 1
                            return
                        elif GPIO.input(18) == 1:
                            global x
                            print ("Total seconds paused: %s" %x)
                            x += 1
                            text.yview(END)
                            refreshGui()
                            time.after(1000, count)
                        else:
                            return

                    elif x >= penaltyTime: #x amount of seconds before auto rinse for penalty
                        global alreadyOperating
                        alreadyOperating == 1
                        if GPIO.input(32) == 1: #while no deadman switch is detected
                            global functionCalled
                            functionCalled = "Drain/Rinse Penalty"
                            logFunction(currentUser, functionCalled)
                            autoDrainRinse()
                                    
                    elif GPIO.input(32) == 1:
                        global x
                        print ("Total seconds paused: %s" %x) #only one that actually prints anything....
                        x += 1
                        #text.yview(END)
                        time.after(1000, count)

                def refusal():
                    text.yview(END)
                    print"Cannot delete window, must press\nresume with DeadMan"
                    text.yview(END)

                def checkState():
                    if state == 1:
                        intruction = Label(rootB, text='Stopped during ***WATER***\n%d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                           font=('Times', 25), bg ='red') 
                        intruction.pack()
                        
                    if state == 2:
                        intruction = Label(rootB, text='Stopped during ***HF***\n%d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                           font=('Times', 25), bg ='red') 
                        intruction.pack()

                    if state == 3:
                        intruction = Label(rootB, text='Stopped during ***NHO3***\n%d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                           font=('Times', 25), bg ='red') 
                        intruction.pack()

                    if state == 4:
                        intruction = Label(rootB, text='Stopped during ***FINAL WATER***\n%d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                           font=('Times', 25), bg ='red') 
                        intruction.pack()
                        
                    count() # timer that counts up for dead man pause

  
                global rootB
                global sec
                global state
                rootB = Tk()
                rootB.attributes('-topmost', 1)
                rootB.overrideredirect(True)
                rootB.geometry("500x700")# Window dimensions(w x h + starting w + starting h)
                rootB.resizable(0, 0) # cannot resize window
                rootB.config(bg='red')
                rootB.title('No Deadman Signal Detected')
                spaceLabel = Label(rootB, text=' \nWARNING\n ', font=('Times', 50), bg ='red') 
                spaceLabel.pack()
                intruction = Label(rootB, text='Press resume to continue', font=('Times', 25), bg ='red') 
                intruction.pack()
                resumeB = Button(rootB, text='Resume', height = 8, width = 25, command=resumeState) 
                resumeB.pack()
                checkState()
        
                
            def resumeState():
                if mayProceed == 1: # bug fix for when alarm and deadMan screen both activate
                    global rootB
                    rootB.destroy()
                    global allowNoStop # control bit to allow stop autoDrainRinse
                    allowNoStop = 0
                    
                if (GPIO.input(32) == 0 and mayProceed == 0):
                    global rootB
                    rootB.destroy()
                    global mayProceed # gets you out of the dman screen counter
                    mayProceed = 1
                    global functionCalled
                    functionCalled = "Resumed Operation"
                    logFunction(currentUser, functionCalled)
                    if state == 1:
                        fillWater() # Functions.py
                        tick() # Functions.py
                        print "Resuming Water\n"
                        text.yview(END)
                    if state == 2:
                        HFfill() # Functions.py
                        waterOpen() # Functions.py
                        print "Resuming HF\n"
                        text.yview(END)
                        tick()
                    if state == 3:
                        NHfill() # Functions.py
                        waterOpen() # Functions.py
                        print "Resuming NHO3\n"
                        text.yview(END)
                        tick()
                    if state == 4:
                        waterOpen() # functions.py
                        print "Resuming Final Water\n"
                        text.yview(END)
                        tick()
                    
                if GPIO.input(32) == 1:
                    print "Hold DeadMan and press resume"
                    text.yview(END)

                    
    
            if GPIO.input(32) == 1: #changed to GPIO.input(32) == 1
                global saveSec
                saveSec = sec
                stop()
                global x
                x = 0
                global mayProceed
                mayProceed = 0
                pause()

            global currentProcess
            #processLabel['text'] = currentProcess

            #Tick Continuation   
            if sec > 0 and GPIO.input(32) == 0:
                global sec
                sec -= 1
                time['text'] = sec
                # update the label here with the (state)

                if GPIO.input(18) == 0 or GPIO.input(22) == 0: #dripSensors
                    stop()
                    tickReset()
                    if(GPIO.input(22) == 0):
                        openDrain()
                
                # Start Water Tick
                if sec > 0 and go == 1 and goHF == 0 and goNH == 0 and  goFW == 0 and GPIO.input(32) == 0:
                    if GPIO.input(32) == 0:
                        time.after(1000, tick)
                        text.yview(END)
                        print ("Water Time Left: %s\n\n\n\n\n" %sec)
                        text.yview(END)
                        global state
                        global currentProcess
                        currentProcess = 'Initial H20'
                        processLabel['text'] = currentProcess
                        state = 1
                        
                        return sec

                #HF Tick
                if sec > 0 and go == 1 and goHF == 1 and goNH == 0 and goFW == 0 and GPIO.input(32) == 0:
                    if GPIO.input(32) == 0:
                        time.after(1000, tick)
                        print ("HF Time Left: %s\n\n\n\n\n" %sec)
                        global state
                        state = 2
                        text.yview(END)
                        return sec

                #NHO3 Tick
                if sec > 0 and go == 1 and goHF == 1 and goNH == 1 and goFW == 0 and GPIO.input(32) == 0:
                    if GPIO.input(32) == 0:
                        time.after(1000, tick)
                        print ("NHO3 Time Left: %s\n\n\n\n\n" %sec)
                        global state
                        state = 3
                        text.yview(END)
                        return sec

                #Final Water Tick
                if sec > 0 and go == 1 and goHF == 1 and goNH == 1 and goFW == 1 and GPIO.input(32) == 0:
                    if GPIO.input(32) == 0:
                        time.after(1000, tick)
                        print ("Water Time Left: %s\n\n\n\n\n" %sec)
                        global state
                        state = 4
                        text.yview(END)
                        return sec

                #Start HF Timer
                if sec == 0 and go == 1 and goHF == 0 and goNH == 0 and goFW == 0 and GPIO.input(32) == 0:
                    time['text'] = sec
                    stop()
                    waterOpen() # turns water valve back on, functions.py
                    global currentProcess
                    currentProcess = 'HF+H20'
                    processLabel['text'] = currentProcess
                    
                    
                    if fillOption is 1:
                        print ("Starting HF Timer: %s seconds." % newHFTime)
                        text.yview(END)
                        tickHF()
                        return sec

                    if fillOption is 2:
                        print ("Starting HF Timer: %s seconds." % newHFTime_Fill2)
                        text.yview(END)
                        tickHF2()
                        return sec

                    if fillOption is 3:
                        print ("Starting HF Timer: %s seconds." % newHFTime_Fill3)
                        text.yview(END)
                        tickHF3()
                        return sec

                    if fillOption is 4:
                        print ("Starting HF Timer: %s seconds." % newHFTime_Fill4)
                        text.yview(END)
                        tickHF4()
                        return sec
                    
                    if fillOption is 5:
                        print ("Starting HF Timer: %s seconds." % newHFTime_Fill5)
                        text.yview(END)
                        tickHF5()
                        return sec
                    
                    if fillOption is 6:
                        print ("Starting HF Timer: %s seconds." % newHFTime_Fill6)
                        text.yview(END)
                        tickHF6()
                        return sec

                #Start NHO3 Timer
                if sec == 0 and goHF == 1 and goNH == 0 and go == 1 and GPIO.input(32) == 0:
                    global saveNH
                    global saveHF
                    global saveWater
                    saveHF = 0
                    saveNH = 1
                    saveWater = 0
                    global currentProcess
                    currentProcess = 'HNO3+H20'
                    processLabel['text'] = currentProcess
                    
                    time['text'] = sec
                    stop()
                    waterOpen() # turns water valve back on, functions.py
                    print "HF Complete"
                    text.yview(END)
                    
                    print ("Starting HNO3 Timer: %s seconds." % newHNTime)
                    text.yview(END)

                    if fillOption is 1:
                        tickNH()
                        text.yview(END)
                        return sec

                    if fillOption is 2:
                        tickNH2()
                        text.yview(END)
                        return sec

                    if fillOption is 3:
                        tickNH3()
                        text.yview(END)
                        return sec

                    if fillOption is 4:
                        tickNH4()
                        text.yview(END)
                        return sec

                    if fillOption is 5:
                        tickNH5()
                        text.yview(END)
                        return sec

                    if fillOption is 6:
                        tickNH6()
                        text.yview(END)
                        return sec
                        

                #Start Final Water Timer
                if sec == 0 and goHF == 1 and goNH == 1 and go == 1 and goFW == 0 and GPIO.input(32) == 0:
                    global saveNH
                    global saveHF
                    global saveWater
                    saveHF = 0
                    saveNH = 1
                    saveWater = 0
                    global currentProcess
                    currentProcess = 'Final H20'
                    processLabel['text'] = currentProcess
                    
                    time['text'] = sec
                    stop()
                    waterOpen() # turns water valve back on, functions.py
                    print "NHO3 Complete"
                    text.yview(END)
                    

                    if fillOption is 1:
                        tickFW(newWaterFinishTime)
                        #print"Final Water Fill"
                        text.yview(END)
                        return sec

                    if fillOption is 2:
                        tickFW(newWaterFinishTime_Fill2)
                        #print"Final Water Fill2"
                        text.yview(END)
                        return sec

                    if fillOption is 3:
                        tickFW(newWaterFinishTime_Fill3)
                        #print"Final Water Fill3"
                        text.yview(END)
                        return sec

                    if fillOption is 4:
                        tickFW(newWaterFinishTime_Fill4)
                        #print"Final Water Fill4"
                        text.yview(END)
                        return sec

                    if fillOption is 5:
                        tickFW(newWaterFinishTime_Fill5)
                        #print"Final Water Fill5"
                        text.yview(END)
                        return sec

                    if fillOption is 6:
                        tickFW(newWaterFinishTime_Fill6)
                        #print"Final Water Fill6"
                        text.yview(END)
                        return sec
                    
                #Hold Timer
                if sec == 0 and goHF == 1 and goNH == 1 and go == 1 and goFW == 1 and (GPIO.input(32) == 0 or GPIO.input(32) == 1):
                    global sec
                    global functionCalled

                    global currentProcess
                    currentProcess = 'Holding'
                    processLabel['text'] = currentProcess
                    global showDrainRinseInfo
                    showDrainRinseInfo = ' '
                    
                    functionCalled = "Holding Acid Solution"
                    logFunction(currentUser, functionCalled)
                    def holdTime(holdSec):
                        allLow() # hold solution, all gpio low to hold liquid
                        text.yview(END)
                        global secz
                        secz = holdSec

                        def autoDrainRinse(): # function to automatically drain and rinse as penalty for not holding dmain switch
                                global y
                                y = drainTime
                                global z
                                z = rinseTime
                                global currentProcess
                                currentProcess = 'Rinse/Drain'
                                processLabel['text'] = currentProcess
                                currentProcess = 'Cycles Remaining: '
                                timeLbl['text'] = currentProcess # overriding the label time remaining
                                
                                showDrainRinseInfo = autoNumberTimesLeft
                                time['text'] = showDrainRinseInfo
                                
                                def autoDrain():
                                    if (GPIO.input(18) == 0 or GPIO.input(22) == 0 or alreadyOperating == 0): #dripSensors check
                                        try:
                                             global rootB
                                             rootB.destroy()
                                        except:
                                            pass
                                        tickReset()
                                        stop()
                                        if(GPIO.input(22) == 0):
                                            openDrain()
                                    else:
                                        drain()
                                        text.yview(END)
                                        processLabel['text'] = ("Draining %s" % y)

                                        if y == 0:
                                            autoRinse()
                                        if y <= drainTime and not y == 0:
                                            global y
                                            print ("Total seconds remaining to drain: %s\nRemaining Cycles: %s\n\n\n" %(y, autoNumberTimesLeft))
                                            y -= 1
                                            
                                            showDrainRinseInfo = autoNumberTimesLeft
                                            time['text'] = showDrainRinseInfo
                                            
                                            text.yview(END)
                                            time.after(1000, autoDrain)
                                def autoRinse():
                                    if (GPIO.input(18) == 0 or GPIO.input(22) == 0 or alreadyOperating == 0): #dripSensors check
                                        try:
                                             global rootB
                                             rootB.destroy()
                                        except:
                                            pass
                                        tickReset()
                                        stop()
                                        if(GPIO.input(22) == 0):
                                            openDrain()
                                    else:
                                        text.yview(END)
                                        rinse()
                                        
                                        showDrainRinseInfo = autoNumberTimesLeft
                                        time['text'] = showDrainRinseInfo
                                        
                                        processLabel['text'] = ("Rinsing %s" % z)
                                        if z == 0:
                                            global autoNumberTimesLeft
                                            autoNumberTimesLeft -= 1
                                            time.after(1000, autoDrainRinse)
                                        if z == 0 and autoNumberTimesLeft == 0: # this works appropriately
                                            stop()
                                            drain()
                                            print"Final drain commencing"
                                            global allowNoStop
                                            allowNoStop = 0
                                            text.yview(END);
                                            
                                        if z >=1:
                                            global z
                                            print ("Total seconds remaining to rinse: %s\nRemaining Cycles: %s\n\n\n" %(z, autoNumberTimesLeft))
                                            z -= 1
                                            text.yview(END)
                                            time.after(1000, autoRinse)

                                if autoNumberTimesLeft > 0:
                                    stop() #make sure everything is off before opening more valves
                                    autoDrain()
                                    
                        def keepHolding():

                            if (GPIO.input(18) == 0 or GPIO.input(22) == 0 or alreadyOperating == 0): #dripSensors check
                                try:
                                     global rootB
                                     rootB.destroy()
                                except:
                                    pass
                                tickReset()
                                stop()
                                
                                
                                if(GPIO.input(22) == 0):
                                    openDrain()

                            time['text'] = secz
                            
                            if secz == 0:
                                    print "Holding Complete, proceeding to autoDrainRinse.\n\n\n\n\n"
                                    text.yview(END)
                                    global autoNumberTimesLeft
                                    autoNumberTimesLeft = 5
                                    autoDrainRinse()
                                    ##drain()####################
                            if secz <= holdSec and not secz == 0 and go == 1:
                                
                                global secz
                                text.yview(END)
                                print ("Holding for: %s seconds before draining.\n\n\n\n\n" %secz)
                                secz -= 1
                                time.after(1000, keepHolding)

                            
                        keepHolding()
                        
                    global holdSecFill
                    holdTime(holdSecFill) #make sure assignments are woking for holdSecFill, change back



        def setCurrentFillButtonColor(btn, color):
            btn.configure(state = "normal", relief = "raised", bg = color)
            
        #finish timer
        def finishTimer():
            text.yview(END)
            global fillOption
            fillOption = 0
            text.yview(END)
            global alreadyOperating
            alreadyOperating = 0
            global warning
            warning = 0
            global fw1
            global fw2
            global fw3
            global fw4
            global fw6
            global fw5
            global fwV
            fw1 = 0
            fw2 = 0
            fw3 = 0
            fw4 = 0
            fw5 = 0
            fw6 = 0
            fwV = 0
            tickReset()
            functionCalled = "Filling Completed Successfully"
            logFunction(currentUser, functionCalled)
            #n2OFF() # turn off the N2 Curtain
            
            global currentProcess
            currentProcess = 'Complete'
            processLabel['text'] = currentProcess
            #resetTimeout()
                
        # Reset Timer
        def tickReset():
            global sec
            sec = 0
            global go
            go = 0
            global x # reset DeadMan Timer
            x = -1
            time['text'] = sec
            print "Timer reset."
            text.yview(END)
            global warning
            warning = 0

        # Start Water Timer
        def tickW():
            if (fw1 and not(fw2 or fw3 or fw4 or fw5 or fw6 or fwV) and alreadyOperating == 0):
                global go
                global newWaterTime
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFill1
                alreadyOperating = 1
                fillOption = 1
                go = 1
                sec = newWaterTime
                goNH = 0
                goHF = 0
                goFW = 0
                #fillWater is defined on fill_proc event
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"
                

        # Start HF Timer
        def tickHF():
            if (fw1 and not(fw2 or fw3 or fw4 or fw5 or fw6 or fwV)):
                global go
                global newHFTime
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime
                HFfill()
                tick()

        #Start NHO3 Timer
        def tickNH():
            if (fw1 and not(fw2 or fw3 or fw4 or fw5 or fw6 or fwV)):
                global go
                global newHNTime
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime
                NHfill()
                tick()

        #Start Final Water Timer
        def tickFW(duration): #todo duration
            global go
            global sec
            global goFW
            goFW = 1
            go = 1
            sec = duration # TODO
            waterOpen() # functions.py
            tick()

        # Start Water Timer 2
        def tickW2():
            if (fw2 and not(fw1 or fw3 or fw4 or fw5 or fw6 or fwV)and alreadyOperating == 0):
                global go
                global newWaterTime_Fill2
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFill2
                alreadyOperating = 1
                fillOption = 2
                go = 1
                sec = newWaterTime_Fill2
                goNH = 0
                goHF = 0
                goFW = 0
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"

       

        # Start HF Timer 2
        def tickHF2():
            if (fw2 and not(fw1 or fw3 or fw4 or fw5 or fw6 or fwV)):
                global go
                global newHFTime_Fill2
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime_Fill2
                HFfill()
                tick()

        #Start NHO3 Timer 2
        def tickNH2():
            if (fw2 and not(fw1 or fw3 or fw4 or fw5 or fw6 or fwV)):
                global go
                global newHNTime_Fill2
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime_Fill2
                NHfill()
                tick()


        # Start Water Timer 3
        def tickW3():
            if (fw3 and not(fw1 or fw2 or fw4 or fw5 or fw6 or fwV)and alreadyOperating == 0):
                global go
                global newWaterTime_Fill3
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFill3
                alreadyOperating = 1
                fillOption = 3
                go = 1
                sec = newWaterTime_Fill3
                goNH = 0
                goHF = 0
                goFW = 0
                #fiillWater is defined on fill_proc event
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"

        # Start HF Timer 3
        def tickHF3():
            if (fw3 and not(fw1 or fw2 or fw4 or fw5 or fw6 or fwV)):
                global go
                global newHFTime_Fill3
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime_Fill3
                HFfill()
                tick()

        #Start NHO3 Timer 3
        def tickNH3():
            if (fw3 and not(fw1 or fw2 or fw4 or fw5 or fw6 or fwV)):
                global go
                global newHNTime_Fill3
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime_Fill3
                NHfill()
                tick()

        # Start Water Timer 4
        def tickW4():
            if (fw4 and not(fw1 or fw2 or fw3 or fw5 or fw6 or fwV)and alreadyOperating == 0):
                global go
                global newWaterTime_Fill4
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFill4
                alreadyOperating = 1
                fillOption = 4
                go = 1
                sec = newWaterTime_Fill4
                goNH = 0
                goHF = 0
                goFW = 0
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"

        # Start HF Timer 4
        def tickHF4():
            if (fw4 and not(fw1 or fw3 or fwV)):
                global go
                global newHFTime_Fill4
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime_Fill4
                HFfill()
                tick()

        #Start NHO3 Timer 4
        def tickNH4():
            if (fw4 and not(fw1 or fw3 or fwV)):
                global go
                global newHNTime_Fill4
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime_Fill4
                NHfill()
                tick()

        # Start Water Timer 5
        def tickW5():
            if (fw5 and not(fw1 or fw2 or fw3 or fw4 or fw6 or fwV)and alreadyOperating == 0):
                global go
                global newWaterTime_Fill5
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFill5
                alreadyOperating = 1
                fillOption = 5
                go = 1
                sec = newWaterTime_Fill5
                goNH = 0
                goHF = 0
                goFW = 0
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"

        # Start HF Timer 5
        def tickHF5():
            if (fw5 and not(fw1 or fw2 or fw3 or fw4 or fw6 or fwV)):
                global go
                global newHFTime_Fill5
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime_Fill5
                HFfill()
                tick()

        #Start NHO3 Timer 5
        def tickNH5():
            if (fw5 and not(fw1 or fw2 or fw3 or fw4 or fw6 or fwV)):
                global go
                global newHNTime_Fill5
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime_Fill5
                NHfill()
                tick()


        # Start Water Timer 6
        def tickW6():
            if (fw6 and not(fw1 or fw2 or fw3 or fw4 or fw5 or fwV)and alreadyOperating == 0):
                global go
                global newWaterTime_Fill5
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFill6
                alreadyOperating = 1
                fillOption = 6
                go = 1
                sec = newWaterTime_Fill6
                goNH = 0
                goHF = 0
                goFW = 0
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"

        # Start HF Timer 6
        def tickHF6():
            if (fw6 and not(fw1 or fw2 or fw3 or fw4 or fw5 or fwV)):
                global go
                global newHFTime_Fill6
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime_Fill6
                HFfill()
                tick()

        #Start NHO3 Timer 6
        def tickNH6():
            if (fw6 and not(fw1 or fw2 or fw3 or fw4 or fw5 or fwV)):
                global go
                global newHNTime_Fill6
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime_Fill6
                NHfill()
                tick()


        # Start Water Timer V
        def tickWV():
            if (fwV and not(fw1 or fw2 or fw3) and (superUser == 1 or isSupervisor == 1)):
                global go
                global newWaterTime_Fill_Variable
                global sec
                global goNH
                global goHF
                global goFW
                global fillOption
                global alreadyOperating
                global holdSecFill # general holdSecFill changed for specific fill after water has finished
                holdSecFill = holdSecFillV
                alreadyOperating = 1
                fillOption = 4
                go = 1
                sec = newWaterTime_Fill_Variable
                goNH = 0
                goHF = 0
                goFW = 0
                #fiillWater is defined on fill_proc event
                tick()
                return sec
            if (alreadyOperating == 1):
                print "Already in operation!"

        # Start HF Timer V
        def tickHFV():
            if (fwV and not(fw1 or fw2 or fw3)):
                global go
                global newHFTime_Fill_Variable
                global goNH
                global sec
                global goHF
                goHF = 1
                goNH = 0
                go = 1
                sec = newHFTime_Fill_Variable
                HFfill()
                tick()

        #Start NHO3 Timer V
        def tickNHV():
            if (fwV and not(fw1 or fw2 or fw3)):
                global go
                global newHNTime_Fill_Variable
                global sec
                global goNH
                goNH = 1
                go = 1
                sec = newHNTime_Fill_Variable
                NHfill()
                tick()


        # Check to see if fill of any type is already in operation
        def isOperating():
            if fw1 and not(fw2 or fw3 or fw4 or fw5 or fw6 or fwV):
                global currentFill
                currentFill = "Fill 1"
                print ("%s already in operation!" % currentFill)
            if fw2 and not(fw1 or fw3 or fw4 or fw5 or fw6 or fwV):
                global currentFill
                currentFill = "Fill 2"
                print ("%s already in operation!" % currentFill)
            if fw3 and not(fw2 or fw1 or fwV or fw5 or fw6 or fwV):
                global currentFill
                currentFill = "Fill 3"
                print ("%s already in operation!" % currentFill)
            if fw4 and not(fw2 or fw3 or fw1 or fw5 or fw6 or fwV):
                global currentFill
                currentFill = "Fill 4"
                print ("%s already in operation!" % currentFill)
            if fw5 and not(fw2 or fw3 or fw4 or fw1 or fw6 or fwV):
                global currentFill
                currentFill = "Fill 5"
                print ("%s already in operation!" % currentFill)
            if fw6 and not(fw2 or fw3 or fw4 or fw5 or fw1 or fwV):
                global currentFill
                currentFill = "Fill 6"
                print ("%s already in operation!" % currentFill)
            if fwV and not(fw2 or fw3 or fw1 or fw5 or fw6 or fw4):
                global currentFill
                currentFill = "Fill V"
                print ("%s already in operation!" % currentFill)
                
           
        # Event Functions
        def wait():
            global fillNum
            print 'Waiting for user to press DeadMan'
            text.yview(END)

            if (stopPressed): # if user presses stop
                print "\n\n\n\n\n\n"
                text.yview(END)
                return
                
            elif (GPIO.input(32) == 0):
                print 'DeadMan detected, proceeding . . .'
                text.yview(END)
                if fillNum == 1:
                    fillproc_event_single()
                if fillNum == 2:
                    fillproc_event_single2()
                if fillNum == 3:
                    fillproc_event_single3()
                if fillNum == 4:
                    fillproc_event_single4()
                if fillNum == 5:
                    fillproc_event_single5()
                if fillNum == 6:
                    fillproc_event_single6()
            else:
                time.after(500, wait)

                            
        def fillproc_event(event):
            text.yview(END)
            if alreadyOperating == 0:
                setCurrentFillButtonColor(buttonf1, "light blue")
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 1
                    global stopPressed
                    stopPressed = False
                    wait()
                else:  
                    global functionCalled
                    functionCalled = "Fill 1"
                    logFunction(currentUser, functionCalled)
                    global fw1
                    fw1 = 1
                    fillWater() #Function.py
                    resetTimeout()
                    tickW()

            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_single(): ## test
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 1
                    wait()
                else:  
                    global functionCalled
                    functionCalled = "Fill 1"
                    logFunction(currentUser, functionCalled)
                    global fw1
                    fw1 = 1
                    fillWater() #Function.py
                    resetTimeout()
                    tickW()

            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event2(event):
            text.yview(END)
            if alreadyOperating == 0:
                setCurrentFillButtonColor(buttonf2, "light blue")
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 2
                    global stopPressed
                    stopPressed = False
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 2"
                    logFunction(currentUser, functionCalled)
                    global fw2
                    fw2 = 1
                    fillWater() #Function.py
                    tickW2()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_single2():
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 2
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 2"
                    logFunction(currentUser, functionCalled)
                    global fw2
                    fw2 = 1
                    fillWater() #Function.py
                    tickW2()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event3(event):
            text.yview(END)
            if alreadyOperating == 0:
                setCurrentFillButtonColor(buttonf3, "light blue")
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 3
                    global stopPressed
                    stopPressed = False
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 3"
                    logFunction(currentUser, functionCalled)
                    global fw3
                    fw3 = 1
                    fillWater() #Function.py
                    tickW3()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_single3():
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 3
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 3"
                    logFunction(currentUser, functionCalled)
                    global fw3
                    fw3 = 1
                    fillWater() #Function.py
                    tickW3()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)


        def fillproc_event4(event):
            text.yview(END)
            if alreadyOperating == 0:
                setCurrentFillButtonColor(buttonf4, "light blue")
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 4
                    global stopPressed
                    stopPressed = False
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 4"
                    logFunction(currentUser, functionCalled)
                    global fw4
                    fw4 = 1
                    fillWater() #Function.py
                    tickW4()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_single4():
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 4
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 4"
                    logFunction(currentUser, functionCalled)
                    global fw4
                    fw4 = 1
                    fillWater() #Function.py
                    tickW4()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)


        def fillproc_event5(event):
            text.yview(END)
            if alreadyOperating == 0:
                setCurrentFillButtonColor(buttonf5, "light blue")
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 5
                    global stopPressed
                    stopPressed = False
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 5"
                    logFunction(currentUser, functionCalled)
                    global fw5
                    fw5 = 1
                    fillWater() #Function.py
                    tickW5()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_single5():
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 5
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 5"
                    logFunction(currentUser, functionCalled)
                    global fw5
                    fw5 = 1
                    fillWater() #Function.py
                    tickW5()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event6(event):
            text.yview(END)
            if alreadyOperating == 0:
                setCurrentFillButtonColor(buttonf6, "light blue")
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 6
                    global stopPressed
                    stopPressed = False
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 6"
                    logFunction(currentUser, functionCalled)
                    global fw6
                    fw6 = 1
                    fillWater() #Function.py
                    tickW6()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_single6():
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 6
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill 6"
                    logFunction(currentUser, functionCalled)
                    global fw6
                    fw6 = 1
                    fillWater() #Function.py
                    tickW6()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        

        def fillproc_eventV(event):
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 4
                    global stopPressed
                    stopPressed = False
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill V"
                    logFunction(currentUser, functionCalled)
                    global fwV
                    fwV = 1
                    fillWater() #Function.py
                    tickWV()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        def fillproc_event_singleV():
            text.yview(END)
            if alreadyOperating == 0:
                if(GPIO.input(32) == 1):
                    global fillNum
                    fillNum = 4
                    wait()
                else:
                    global functionCalled
                    functionCalled = "Fill V"
                    logFunction(currentUser, functionCalled)
                    global fwV
                    fwV = 1
                    fillWater() #Function.py
                    tickWV()
                    resetTimeout()
            else:
                if alreadyOperating == 1:
                    isOperating()
                else:
                    print "No DeadMan Switch Signal"
            text.yview(END)

        # Event Functions
        def stop_event(event):
            if allowNoStop == 0:
                stop()
                tickReset()
                print("Stopped.")
                text.yview(END)
                global functionCalled
                functionCalled = "STOP"

                try:
                    logFunction(currentUser, functionCalled) # gets rid of bug where no user click emo and won't be recorded
                except:
                    pass
                
                global alreadyOperating
                alreadyOperating = 0
                global fw1 #fillWater1 control bit to determine which recipe is running.
                global fw2
                global fw3
                global fw4
                global fw5
                global fw6
                global fwV
                fw1 = 0
                fw2 = 0
                fw3 = 0
                fw4 = 0
                fw5 = 0
                fw6 = 0
                fwV = 0

                for b in btnArray: # change buttons back to original color
                    setCurrentFillButtonColor(b, originalColor)

                global currentProcess
                currentProcess = 'Stopped'
                processLabel['text'] = currentProcess
                currentProcess = 'Time Remaining: '
                timeLbl['text'] = currentProcess # overriding the label time remaining
                time['text'] = 0

                if(alreadyOperating is 0):
                    n2OFF() # turn off the N2 Curtain
           
        def nextRecipe_event(event):
            if alreadyOperating == 1:
                 print ("Recipe must finish!")
                 text.yview(END)
            else:
                stop()
                tickReset()
                print("Ready for next recipe.")
                text.yview(END)
                global functionCalled
                functionCalled = "STOP"

                try:
                    logFunction(currentUser, functionCalled) # try gets rid of bug where no user click emo and won't be recorded
                except:
                    pass
                
                global alreadyOperating
                alreadyOperating = 0
                global fw1
                global fw2
                global fw3
                global fw4
                global fw5
                global fw6
                global fwV
                fw1 = 0
                fw2 = 0
                fw3 = 0
                fw4 = 0
                fw5 = 0
                fw6 = 0
                fwV = 0

                global currentProcess
                currentProcess = 'Ready'
                processLabel['text'] = currentProcess
                currentProcess = 'Time Remaining: '
                timeLbl['text'] = currentProcess # overriding the label time remaining
                time['text'] = 0

        def resume_event(event):
            print("Resuming Operation")
            text.yview(END)

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

            def clear(self):
                text.delete(0, END)

        def clear():
            print "\n\n\n\n\n\n\n"
            text.yview(END)

        def threadLogout():
            controller.show_frame(MainMenu)
            timeoutLogoutUser(currentUser) #record when which user logs out
            print "Session timed out . . ."
            text.yview(END)
            global superUser
            superUser = 0
            global isSupervisor # sets supervisor control bit back to 0
            isSupervisor = 0

        def allowLogout(event): #check to see if anything is in operation before allowing user to logout
            if (alreadyOperating == 0):
                clear() #clear text entry
                controller.show_frame(MainMenu)
                print "Successfully logged out.\n\n\n\n\n"
                try:
                    t.cancel() # cancel if thread is started for normal user
                except:
                    pass
                    
                text.yview(END)
                logoutUser(currentUser) #record when which user logs out
                global superUser
                superUser = 0
                #restart_program() # called from functions.py
                global isSupervisor # sets supervisor control bit back to 0
                isSupervisor = 0
            else:
                print "Operation must finish!"
                text.yview(END)

        global drainStartSecs # secs to hold for drain activation
        drainStartSecs = 0
        global drainButtonContinue # control bit for button held boolean
        drainButtonContinue = 0
        
        def promptDrain(event): # if only one click is applied to drain button
            if(drainStartSecs < 3 and drainButtonContinue == 1): # hold for three seconds or reset
                print "Hold Drain Button to start Drain."
                text.yview(END)
        
            global drainButtonContinue
            drainButtonContinue = 0
            global drainStartSecs # reset secs to hold for drain activation
            drainStartSecs = 0

        def holdDrain(event):
            global drainButtonContinue
            drainButtonContinue = 1

            def continueDrainCount(event):
                if (drainStartSecs == 3 and drainButtonContinue == 1):
                    startDrain(event)
                    global currentProcess
                    currentProcess = 'Draining'
                    processLabel['text'] = currentProcess
                    currentProcess = 'Drain OPEN'
                    timeLbl['text'] = currentProcess # overriding the label time remaining
                    time['text'] = ''
                elif(drainButtonContinue == 1 and drainStartSecs < 3):
                    global drainStartSecs
                    drainStartSecs += 1
                    print 'Seconds left until Drain: %d' % ((drainStartSecs * -1) + 4)
                    text.yview(END)
                    time.after(1000, continueDrainCount, event)
            continueDrainCount(event)
            
        def startDrain(event): #start draining
            if (alreadyOperating == 0):
                print "starting drain"
                global functionCalled
                functionCalled = "Drain"
                logFunction(currentUser, functionCalled)
                text.yview(END)
                drain()
                resetTimeout()
            else:
                print "Operation must finish!"
                text.yview(END)

        def resetTimeout():
            global t
            try:
                t.cancel()
            except:
                pass
            global timeoutTime
            t = Timer(timeoutTime, threadLogout) # change to 3600 seconds for 1 hr
            t.start()


        def timeOut(event):
           global ts
           
        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        
        label = tk.Label(self, text="Recipe Menu", font=('Times', 50))
        label.pack()

        label2 = tk.Label(self, text=" ", font=('Times', 10))
        label2.pack()

        frame4 = tk.Frame(self)
        frame4.pack(anchor = N, side = TOP)

        
        processLbl = Label(frame4, fg='black', text='Process: ', font =("Courier", 30)).grid(row = 0, column = 0)
        processLabel = Label(frame4, fg='blue', font =("Courier", 25) )
        processLabel.grid(row = 0, column = 1)

        frame5 = tk.Frame(self)
        frame5.pack(anchor = N, side = TOP)
        
        
        timeLbl = Label(frame5, fg='black', font =("Courier", 30))
        timeLbl['text'] = 'Remaining Time: ' # you can't update the text in a label if it's not in this format.
        timeLbl.grid(row = 0, column = 0)
        time = Label(frame5, fg='red', font =("Courier", 30) )
        time.grid(row = 0, column = 1)

        frame2=tk.Frame(self, borderwidth=0, pady=0) # third frame next to middle frame
        frame2.bind(not "<Button-1>", timeOut)
        frame2.pack(anchor = N)

        buttonf1 = tk.Button(frame2, text="Recipe 1", height=5, width=20)
        buttonf1.bind("<Button-1>", fillproc_event)
        buttonf1.grid(row=0, column=0)

        buttonf2 = tk.Button(frame2, text="Recipe 2", height=5, width=20)
        buttonf2.bind("<Button-1>", fillproc_event2)
        buttonf2.grid(row=1, column=0)

        buttonf3 = tk.Button(frame2, text="Recipe 3", height=5, width=20)
        buttonf3.bind("<Button-1>", fillproc_event3)
        buttonf3.grid(row=2, column=0)

        buttonf4 = tk.Button(frame2, text="Recipe 4", height=5, width=20)
        buttonf4.bind("<Button-1>", fillproc_event4)
        buttonf4.grid(row=0, column=1)

        buttonf5 = tk.Button(frame2, text="Recipe 5", height=5, width=20)
        buttonf5.bind("<Button-1>", fillproc_event5)
        buttonf5.grid(row=1, column=1)

        buttonf6 = tk.Button(frame2, text="Recipe 6", height=5, width=20)
        buttonf6.bind("<Button-1>", fillproc_event6)
        buttonf6.grid(row=2, column=1)

        btnArray = [buttonf1, buttonf2, buttonf3, buttonf4, buttonf5, buttonf6]

        buttonD = tk.Button(frame2, text="Drain", height=5, width=20)
        buttonD.bind('<ButtonPress-1>', holdDrain)
        buttonD.bind('<ButtonRelease-1>', promptDrain)
        buttonD.grid(row=3, column=1)
        
        '''buttonC = tk.Button(frame2, text="Clear", height=6, width=20,
                            command=clear)
        buttonC.grid(row=4, column = 1)'''

        button2 = tk.Button(frame2, text="Logout", height=5, width=20)
        button2.bind('<Button-1>', allowLogout)
        button2.grid(row=4, column = 1)
        
        button3 = tk.Button(frame2, text="E-STOP", height=3, width=15, bg = "red", fg = "black", font = ("Times", 10, "bold")) #frame2 instead of self for position inside of frame 2
        button3.bind("<Button-1>", stop_event)
        button3.grid(row=4, column=0)

        buttonNextRecipe = tk.Button(frame2, text="Next Recipe", height=3, width=15, bg = "light green", fg = "black", font = ("Times", 15)) #frame2 instead of self for position inside of frame 2
        buttonNextRecipe.bind("<Button-1>", nextRecipe_event)
        buttonNextRecipe.grid(row=3, column=0)\

        global originalColor
        originalColor = button2.cget("background")

        global text
        text = Text(width=50, height=7)
        text.place(x=60, y=620)

        

  

        

'''__________________________________________Fill Options__________________________________________'''

# Change different types of fill
class FillChangeFrame(tk.Frame):
    def __init__(self, parent, controller):
        
        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

        def test():
            
            global newHFTime
            global newWaterTime
            global newHNTime

            global newHFTime_Fill2
            global newWaterTime_Fill2
            global newHNTime_Fill2

            global newHFTime_Fill3
            global newWaterTime_Fill3
            global newHNTime_Fill3

            global newHFTime_Fill_Variable
            global newWaterTime_Fill_Variable
            global newHNTime_Fill_Variable

            print "Fill 1 (Water, HF, NHO3):"
            print newHFTime
            print newWaterTime
            print newHNTime
            print "\n"

            print "Fill 2 (Water, HF, NHO3):"
            print newHFTime_Fill2
            print newWaterTime_Fill2
            print newHNTime_Fill2
            print "\n"

            print "Fill 3 (Water, HF, NHO3):"
            print newHFTime_Fill3
            print newWaterTime_Fill3
            print newHNTime_Fill3
            print " "


            print "Fill 4 (Water, HF, NHO3):"
            print newHFTime_Fill4
            print newWaterTime_Fill4
            print newHNTime_Fill4
            print " "

            print "Fill 5 (Water, HF, NHO3):"
            print newHFTime_Fill5
            print newWaterTime_Fill5
            print newHNTime_Fill5
            print " "

            print "Fill 6 (Water, HF, NHO3):"
            print newHFTime_Fill6
            print newWaterTime_Fill6
            print newHNTime_Fill6
            print " "

            
            print "Fill Variable (Water, HF, NHO3):"
            print newHFTime_Fill_Variable
            print newWaterTime_Fill_Variable
            print newHNTime_Fill_Variable
            text.yview(END)
             
                

        sys.stdout = PrintText()
        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Change Fill Options", font=('Times', 30))
        label.pack(pady=15, padx=10)

        #spaceLabel = tk.Label(self, text = ' ', font=('Roman', 20)).pack()

        frame2 = tk.Frame(self)
        frame2.pack(anchor = N, side = TOP)

        button2 = tk.Button(frame2, text="Recipe 1",
                            command=lambda: controller.show_frame(ChangeRecipeFrame), height = 6, width = 25)
        button2.grid(row=0, column=0)
        
        button3 = tk.Button(frame2, text="Recipe 2",
                            command=lambda: controller.show_frame(ChangeRecipeFrame_Fill2), height = 6, width = 25)
        button3.grid(row=1, column=0)
        
        button4 = tk.Button(frame2, text="Recipe 3",
                            command=lambda: controller.show_frame(ChangeRecipeFrame_Fill3), height = 6, width = 25)
        button4.grid(row=2, column=0)


        button8 = tk.Button(frame2, text="Recipe 4",
                            command=lambda: controller.show_frame(ChangeRecipeFrame_Fill4), height = 6, width = 25)
        button8.grid(row=0, column=1)

        button7 = tk.Button(frame2, text="Recipe 5",
                            command=lambda: controller.show_frame(ChangeRecipeFrame_Fill5), height = 6, width = 25)
        button7.grid(row=1, column=1)

        button6 = tk.Button(frame2, text="Recipe 6",
                            command=lambda: controller.show_frame(ChangeRecipeFrame_Fill6), height = 6, width = 25)
        button6.grid(row=2, column=1)

        button5 = tk.Button(self, text="Recipe Variable",
                            command=lambda: controller.show_frame(ChangeRecipeFrame_Fill_Variable), height = 6, width = 25)
                
        button5.pack()

        spaceLabel2 = tk.Label(self, text = ' ', font=('Roman', 20)).pack()

        button1 = tk.Button(self, text="return", height = 6, width = 25,
                            command=lambda: controller.show_frame(OptionFrame))
        button1.pack()



"___________________________________Change Recipe 1_________________________________________________"    
class ChangeRecipeFrame(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill1", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill 1 settings saved"
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            print "Hold time set to: " + changeTimeHold.get() + " seconds."
            print "Finish Water time set to: " + changeFinishTimeWater.get() + " seconds."
            setFinishWater()
            text.yview(END)
            setWater()
            setHF()
            setHN()
            setHold()
            

   
        # Set new Water time
        def setWater():
            global secW
            global newWaterTime
            newWaterTime = changeTimeWater.get()
            secW = int(newWaterTime)# turn string into an int
            newWaterTime = secW

        # Set new HF Time
        def setHF():
            global secHF
            global newHFTime
            newHFTime = changeTimeHF.get()
            secHF = int(newHFTime)  # turn string into an int
            newHFTime = secHF

        # Set new NHO3 Time
        def setHN():
            global secHN
            global newHNTime
            newHNTime = changeTimeHN.get()
            secHN = int(newHNTime)  # turn string into an int
            newHNTime = secHN

        # Set new hold Time
        def setHold():
            global secHold
            global newHoldTime
            newHoldTime = changeTimeHold.get()
            secHold = int(newHoldTime)  # turn string into an int
            newHoldTime = secHold
            global holdSecFill1
            holdSecFill1 = newHoldTime

        # Set new Water time
        def setFinishWater():
            global secFW
            global newWaterFinishTime
            newWaterFinishTime = changeFinishTimeWater.get()
            secFW = int(newWaterFinishTime)# turn string into an int
            newWaterFinishTime = secFW




        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, font=('Times', 20), text="Start Water (seconds): ")
        L2.pack()


        # Water Text Widget
        global newWaterTime
        newWaterTime = StringVar()
        newWaterTime.set(waterFill1Time) #default water time
        changeTimeWater = tk.Entry(self, font=('Times', 20), text="Water (seconds): ", textvariable=newWaterTime)
        changeTimeWater.pack()

        L3 = tk.Label(self, font=('Times', 20), text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime
        newHFTime = StringVar()
        newHFTime.set(hfFill1Time) # default HF time
        changeTimeHF = tk.Entry(self, font=('Times', 20), text="HF (seconds): ", textvariable=newHFTime)
        changeTimeHF.pack()

        L4 = tk.Label(self, font=('Times', 20), text="NHO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime
        newHNTime = StringVar()
        newHNTime.set(nhFill1Time) # default NHO3 time
        changeTimeHN = tk.Entry(self, font=('Times', 20), text="HNO3 (seconds): ", textvariable=newHNTime)
        changeTimeHN.pack()

        L5 = tk.Label(self, font=('Times', 20), text="Hold Time (seconds): ")
        L5.pack()

        # Hold Time Text Widget
        global newHoldTime
        newHoldTime = StringVar()
        newHoldTime.set(holdSecFill1) # default hold time
        changeTimeHold = tk.Entry(self, font=('Times', 20), text="Hold time (seconds): ", textvariable=newHoldTime)
        changeTimeHold.pack()

        L6 = tk.Label(self, font=('Times', 20), text="Finish Water (seconds): ")
        L6.pack()
        # final Water Text Widget
        global newWaterFinishTime_Fill
        newWaterFinishTime_Fill = StringVar()
        newWaterFinishTime_Fill.set(FWFillTime) #default water time
        changeFinishTimeWater = tk.Entry(self, font=('Times', 20), text="Water after acids: (seconds): ", textvariable=newWaterFinishTime_Fill)
        changeFinishTimeWater.pack()


        S2 = tk.LabelFrame(self, height=20)
        S2.pack()     
        

        # save button
        button1 = tk.Button(self, text="save", width=20, font=('Times', 20), height=3, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, font=('Times', 20), height=3, text="return", width=20,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
       
        
        callback()
     
"_____________________________________Change Recipe 2______________________________________________"    
class ChangeRecipeFrame_Fill2(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)
                # text.delete('1.0', END)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill2", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill 2 settings saved."
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            print "Hold time set to: " + changeTimeHold.get() + " seconds."
            print "Finish Water time set to: " + changeFinishTimeWater.get() + " seconds."
            setFinishWater()
            text.yview(END)
            setWater()
            setHF()
            setHN()
            setHold()

   
        # Set new Water time
        def setWater():
            global secW_Fill2
            global newWaterTime_Fill2
            newWaterTime_Fill2 = changeTimeWater.get()
            secW_Fill2 = int(newWaterTime_Fill2)# turn string into an int
            newWaterTime_Fill2 = secW_Fill2

        # Set new HF Time
        def setHF():
            global secHF_Fill2
            global newHFTime_Fill2
            newHFTime_Fill2 = changeTimeHF.get()
            secHF_Fill2 = int(newHFTime_Fill2)  # turn string into an int
            newHFTime_Fill2 = secHF_Fill2

        # Set new NHO3 Time
        def setHN():
            global secHN_Fill2
            global newHNTime_Fill2
            newHNTime_Fill2 = changeTimeHN.get()
            secHN_Fill2 = int(newHNTime_Fill2)  # turn string into an int
            newHNTime_Fill2 = secHN_Fill2

        # Set new hold Time
        def setHold():
            global secHold
            global newHoldTime
            newHoldTime = changeTimeHold.get()
            secHold = int(newHoldTime)  # turn string into an int
            newHoldTime = secHold
            global holdSecFill2
            holdSecFill2 = newHoldTime

        # Set new Water FINISH time
        def setFinishWater():
            global secFW_Fill2
            global newWaterFinishTime_Fill2
            newWaterFinishTime_Fill2 = changeFinishTimeWater.get()
            secFW_Fill2 = int(newWaterFinishTime_Fill2)# turn string into an int
            newWaterFinishTime_Fill2 = secFW_Fill2


        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, font=('Times', 20), text="Start Water (seconds): ")
        L2.pack()


        # Water Text Widget
        global newWaterTime_Fill2
        newWaterTime_Fill2 = StringVar()
        newWaterTime_Fill2.set(waterFill2Time) #default water time
        changeTimeWater = tk.Entry(self, font=('Times', 20), text="Water (seconds): ", textvariable=newWaterTime_Fill2)
        changeTimeWater.pack()

        L3 = tk.Label(self, font=('Times', 20), text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime_Fill2
        newHFTime_Fill2 = StringVar()
        newHFTime_Fill2.set(hfFill2Time) # default HF time
        changeTimeHF = tk.Entry(self, font=('Times', 20), text="HF (seconds): ", textvariable=newHFTime_Fill2)
        changeTimeHF.pack()

        L4 = tk.Label(self, font=('Times', 20), text="HNO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime_Fill2
        newHNTime_Fill2 = StringVar()
        newHNTime_Fill2.set(nhFill2Time) # default NHO3 time
        changeTimeHN = tk.Entry(self, font=('Times', 20), text="HNO3 (seconds): ", textvariable=newHNTime_Fill2)
        changeTimeHN.pack()

        L5 = tk.Label(self, font=('Times', 20), text="Hold Time (seconds): ")
        L5.pack()

        # Hold Time Text Widget
        global newHoldTime
        newHoldTime = StringVar()
        newHoldTime.set(holdSecFill2) # default hold time
        changeTimeHold = tk.Entry(self, font=('Times', 20), text="Hold time (seconds): ", textvariable=newHoldTime)
        changeTimeHold.pack()

        L6 = tk.Label(self, font=('Times', 20), text="Finish Water (seconds): ")
        L6.pack()
        # final Water Text Widget
        global newWaterFinishTime_Fill2
        newWaterFinishTime_Fill2 = StringVar()
        newWaterFinishTime_Fill2.set(FWFillTime2) #default water time
        changeFinishTimeWater = tk.Entry(self, font=('Times', 20), text="Water after acids: (seconds): ", textvariable=newWaterFinishTime_Fill2)
        changeFinishTimeWater.pack()

        S2 = tk.LabelFrame(self, height=20)
        S2.pack()

        # save button
        button1 = tk.Button(self, text="save", width=20, font=('Times', 20), height=3, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, font=('Times', 20), height=3, text="return", width=20,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
        callback()

"_____________________________________Change Recipe 3______________________________________________"    
class ChangeRecipeFrame_Fill3(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill3", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill 3 settings saved."
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            print "Hold time set to: " + changeTimeHold.get() + " seconds."
            print "Finish Water time set to: " + changeFinishTimeWater.get() + " seconds."
            setFinishWater()
            text.yview(END)
            setWater()
            setHF()
            setHN()
            setHold()

   
        # Set new Water time
        def setWater():
            global secW_Fill3
            global newWaterTime_Fill3
            newWaterTime_Fill3 = changeTimeWater.get()
            secW_Fill3 = int(newWaterTime_Fill3)# turn string into an int
            newWaterTime_Fill3 = secW_Fill3

        # Set new HF Time
        def setHF():
            global secHF_Fill3
            global newHFTime_Fill3
            newHFTime_Fill3 = changeTimeHF.get()
            secHF_Fill3 = int(newHFTime_Fill3)  # turn string into an int
            newHFTime_Fill3 = secHF_Fill3

        # Set new NHO3 Time
        def setHN():
            global secHN_Fill3
            global newHNTime_Fill3
            newHNTime_Fill3 = changeTimeHN.get()
            secHN_Fill3 = int(newHNTime_Fill3)  # turn string into an int
            newHNTime_Fill3 = secHN_Fill3

        # Set new hold Time
        def setHold():
            global secHold
            global newHoldTime
            newHoldTime = changeTimeHold.get()
            secHold = int(newHoldTime)  # turn string into an int
            newHoldTime = secHold
            global holdSecFill3
            holdSecFill3 = newHoldTime

        # Set new Water FINISH time
        def setFinishWater():
            global secFW_Fill3
            global newWaterFinishTime_Fill3
            newWaterFinishTime_Fill3 = changeFinishTimeWater.get()
            secFW_Fill3 = int(newWaterFinishTime_Fill3)# turn string into an int
            newWaterFinishTime_Fill3 = secFW_Fill3


        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, font=('Times', 20), text="Start Water (seconds): ")
        L2.pack()


        # first Water Text Widget
        global newWaterTime_Fill3
        newWaterTime_Fill3 = StringVar()
        newWaterTime_Fill3.set(waterFill3Time) #default water time
        changeTimeWater = tk.Entry(self, font=('Times', 20), text="Water (seconds): ", textvariable=newWaterTime_Fill3)
        changeTimeWater.pack()

        L3 = tk.Label(self, font=('Times', 20), text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime_Fill3
        newHFTime_Fill3 = StringVar()
        newHFTime_Fill3.set(hfFill3Time) # default HF time
        changeTimeHF = tk.Entry(self, font=('Times', 20), text="HF (seconds): ", textvariable=newHFTime_Fill3)
        changeTimeHF.pack()

        L4 = tk.Label(self, font=('Times', 20), text="HNO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime_Fill3
        newHNTime_Fill3 = StringVar()
        newHNTime_Fill3.set(nhFill3Time) # default NHO3 time
        changeTimeHN = tk.Entry(self, font=('Times', 20), text="HNO3 (seconds): ", textvariable=newHNTime_Fill3)
        changeTimeHN.pack()

        L5 = tk.Label(self, font=('Times', 20), text="Hold Time (seconds): ")
        L5.pack()

        # Hold Time Text Widget
        global newHoldTime
        newHoldTime = StringVar()
        newHoldTime.set(holdSecFill3) # default hold time
        changeTimeHold = tk.Entry(self, font=('Times', 20), text="Hold time (seconds): ", textvariable=newHoldTime)
        changeTimeHold.pack()

        L6 = tk.Label(self, font=('Times', 20), text="Finish Water (seconds): ")
        L6.pack()
        # final Water Text Widget
        global newWaterFinishTime_Fill3
        newWaterFinishTime_Fill3 = StringVar()
        newWaterFinishTime_Fill3.set(FWFillTime3) #default water time
        changeFinishTimeWater = tk.Entry(self, font=('Times', 20), text="Water after acids: (seconds): ", textvariable=newWaterFinishTime_Fill3)
        changeFinishTimeWater.pack()

        S2 = tk.LabelFrame(self,font=('Times', 20), height=20)
        S2.pack()

        # save button
        button1 = tk.Button(self, text="save", width=20, font=('Times', 20), height=3, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, font=('Times', 20), height=3, text="return", width=20,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
        callback()




"___________________________________Change Recipe 4_________________________________________________"    
class ChangeRecipeFrame_Fill4(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill4", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill 4 settings saved."
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            print "Hold time set to: " + changeTimeHold.get() + " seconds."
            print "Finish Water time set to: " + changeFinishTimeWater.get() + " seconds."
            setFinishWater()
            text.yview(END)
            setWater()
            setHF()
            setHN()
            setHold()

   
        # Set new Water time
        def setWater():
            global secW_Fill4
            global newWaterTime_Fill4
            newWaterTime_Fill4 = changeTimeWater.get()
            secW_Fill4 = int(newWaterTime_Fill4)# turn string into an int
            newWaterTime_Fill4 = secW_Fill4

        # Set new HF Time
        def setHF():
            global secHF_Fill4
            global newHFTime_Fill4
            newHFTime_Fill4 = changeTimeHF.get()
            secHF_Fill4 = int(newHFTime_Fill4)  # turn string into an int
            newHFTime_Fill4 = secHF_Fill4

        # Set new NHO3 Time
        def setHN():
            global secHN_Fill4
            global newHNTime_Fill4
            newHNTime_Fill4 = changeTimeHN.get()
            secHN_Fill4 = int(newHNTime_Fill4)  # turn string into an int
            newHNTime_Fill4 = secHN_Fill4

        # Set new hold Time
        def setHold():
            global secHold
            global newHoldTime
            newHoldTime = changeTimeHold.get()
            secHold = int(newHoldTime)  # turn string into an int
            newHoldTime = secHold
            global holdSecFill4
            holdSecFill4 = newHoldTime

        # Set new Water FINISH time
        def setFinishWater():
            global secFW_Fill4
            global newWaterFinishTime_Fill4
            newWaterFinishTime_Fill4 = changeFinishTimeWater.get()
            secFW_Fill4 = int(newWaterFinishTime_Fill4)# turn string into an int
            newWaterFinishTime_Fill4 = secFW_Fill4


        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, font=('Times', 20), text="Start Water (seconds): ")
        L2.pack()


        # first Water Text Widget
        global newWaterTime_Fill4
        newWaterTime_Fill4 = StringVar()
        newWaterTime_Fill4.set(waterFill4Time) #default water time
        changeTimeWater = tk.Entry(self, font=('Times', 20), text="Water (seconds): ", textvariable=newWaterTime_Fill4)
        changeTimeWater.pack()

        L3 = tk.Label(self, font=('Times', 20), text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime_Fill4
        newHFTime_Fill4 = StringVar()
        newHFTime_Fill4.set(hfFill4Time) # default HF time
        changeTimeHF = tk.Entry(self, font=('Times', 20), text="HF (seconds): ", textvariable=newHFTime_Fill4)
        changeTimeHF.pack()

        L4 = tk.Label(self, font=('Times', 20), text="HNO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime_Fill4
        newHNTime_Fill4 = StringVar()
        newHNTime_Fill4.set(nhFill4Time) # default NHO3 time
        changeTimeHN = tk.Entry(self, font=('Times', 20), text="HNO3 (seconds): ", textvariable=newHNTime_Fill4)
        changeTimeHN.pack()

        L5 = tk.Label(self, font=('Times', 20), text="Hold Time (seconds): ")
        L5.pack()

        # Hold Time Text Widget
        global newHoldTime
        newHoldTime = StringVar()
        newHoldTime.set(holdSecFill4) # default hold time
        changeTimeHold = tk.Entry(self, font=('Times', 20), text="Hold time (seconds): ", textvariable=newHoldTime)
        changeTimeHold.pack()

        L6 = tk.Label(self, font=('Times', 20), text="Finish Water (seconds): ")
        L6.pack()
        # final Water Text Widget
        global newWaterFinishTime_Fill4
        newWaterFinishTime_Fill4 = StringVar()
        newWaterFinishTime_Fill4.set(FWFillTime4) #default water time
        changeFinishTimeWater = tk.Entry(self, font=('Times', 20), text="Water after acids: (seconds): ", textvariable=newWaterFinishTime_Fill4)
        changeFinishTimeWater.pack()

        S2 = tk.LabelFrame(self,font=('Times', 20), height=20)
        S2.pack()

        # save button
        button1 = tk.Button(self, text="save", width=20, font=('Times', 20), height=3, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, font=('Times', 20), height=3, text="return", width=20,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
        callback()


"___________________________________Change Recipe 5_________________________________________________"    
class ChangeRecipeFrame_Fill5(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill5", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill 5 settings saved."
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            print "Hold time set to: " + changeTimeHold.get() + " seconds."
            print "Finish Water time set to: " + changeFinishTimeWater.get() + " seconds."
            setFinishWater()
            text.yview(END)
            setWater()
            setHF()
            setHN()
            setHold()

   
        # Set new Water time
        def setWater():
            global secW_Fill5
            global newWaterTime_Fill5
            newWaterTime_Fill5 = changeTimeWater.get()
            secW_Fill5 = int(newWaterTime_Fill5)# turn string into an int
            newWaterTime_Fill5 = secW_Fill5

        # Set new HF Time
        def setHF():
            global secHF_Fill5
            global newHFTime_Fill5
            newHFTime_Fill5 = changeTimeHF.get()
            secHF_Fill5 = int(newHFTime_Fill5)  # turn string into an int
            newHFTime_Fill5 = secHF_Fill5

        # Set new NHO3 Time
        def setHN():
            global secHN_Fill5
            global newHNTime_Fill5
            newHNTime_Fill5 = changeTimeHN.get()
            secHN_Fill5 = int(newHNTime_Fill5)  # turn string into an int
            newHNTime_Fill5 = secHN_Fill5

        # Set new hold Time
        def setHold():
            global secHold
            global newHoldTime
            newHoldTime = changeTimeHold.get()
            secHold = int(newHoldTime)  # turn string into an int
            newHoldTime = secHold
            global holdSecFill5
            holdSecFill5 = newHoldTime

        # Set new Water FINISH time
        def setFinishWater():
            global secFW_Fill5
            global newWaterFinishTime_Fill5
            newWaterFinishTime_Fill5 = changeFinishTimeWater.get()
            secFW_Fill5 = int(newWaterFinishTime_Fill5)# turn string into an int
            newWaterFinishTime_Fill5 = secFW_Fill5


        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, font=('Times', 20), text="Start Water (seconds): ")
        L2.pack()


        # first Water Text Widget
        global newWaterTime_Fill5
        newWaterTime_Fill5 = StringVar()
        newWaterTime_Fill5.set(waterFill5Time) #default water time
        changeTimeWater = tk.Entry(self, font=('Times', 20), text="Water (seconds): ", textvariable=newWaterTime_Fill5)
        changeTimeWater.pack()

        L3 = tk.Label(self, font=('Times', 20), text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime_Fill5
        newHFTime_Fill5 = StringVar()
        newHFTime_Fill5.set(hfFill5Time) # default HF time
        changeTimeHF = tk.Entry(self, font=('Times', 20), text="HF (seconds): ", textvariable=newHFTime_Fill5)
        changeTimeHF.pack()

        L4 = tk.Label(self, font=('Times', 20), text="HNO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime_Fill5
        newHNTime_Fill5 = StringVar()
        newHNTime_Fill5.set(nhFill5Time) # default NHO3 time
        changeTimeHN = tk.Entry(self, font=('Times', 20), text="HNO3 (seconds): ", textvariable=newHNTime_Fill5)
        changeTimeHN.pack()

        L5 = tk.Label(self, font=('Times', 20), text="Hold Time (seconds): ")
        L5.pack()

        # Hold Time Text Widget
        global newHoldTime
        newHoldTime = StringVar()
        newHoldTime.set(holdSecFill5) # default hold time
        changeTimeHold = tk.Entry(self, font=('Times', 20), text="Hold time (seconds): ", textvariable=newHoldTime)
        changeTimeHold.pack()

        L6 = tk.Label(self, font=('Times', 20), text="Finish Water (seconds): ")
        L6.pack()
        # final Water Text Widget
        global newWaterFinishTime_Fill5
        newWaterFinishTime_Fill5 = StringVar()
        newWaterFinishTime_Fill5.set(FWFillTime5) #default water time
        changeFinishTimeWater = tk.Entry(self, font=('Times', 20), text="Water after acids: (seconds): ", textvariable=newWaterFinishTime_Fill5)
        changeFinishTimeWater.pack()

        S2 = tk.LabelFrame(self,font=('Times', 20), height=20)
        S2.pack()

        # save button
        button1 = tk.Button(self, text="save", width=20, font=('Times', 20), height=3, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, font=('Times', 20), height=3, text="return", width=20,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
        callback()

"___________________________________Change Recipe 6_________________________________________________"    
class ChangeRecipeFrame_Fill6(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill6", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill 6 settings saved."
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            print "Hold time set to: " + changeTimeHold.get() + " seconds."
            print "Finish Water time set to: " + changeFinishTimeWater.get() + " seconds."
            setFinishWater()
            text.yview(END)
            setWater()
            setHF()
            setHN()
            setHold()

   
        # Set new Water time
        def setWater():
            global secW_Fill6
            global newWaterTime_Fill6
            newWaterTime_Fill6 = changeTimeWater.get()
            secW_Fill6 = int(newWaterTime_Fill6)# turn string into an int
            newWaterTime_Fill6 = secW_Fill6

        # Set new HF Time
        def setHF():
            global secHF_Fill6
            global newHFTime_Fill6
            newHFTime_Fill6 = changeTimeHF.get()
            secHF_Fill6 = int(newHFTime_Fill6)  # turn string into an int
            newHFTime_Fill6 = secHF_Fill6

        # Set new NHO3 Time
        def setHN():
            global secHN_Fill6
            global newHNTime_Fill6
            newHNTime_Fill6 = changeTimeHN.get()
            secHN_Fill6 = int(newHNTime_Fill6)  # turn string into an int
            newHNTime_Fill6 = secHN_Fill6

        # Set new hold Time
        def setHold():
            global secHold
            global newHoldTime
            newHoldTime = changeTimeHold.get()
            secHold = int(newHoldTime)  # turn string into an int
            newHoldTime = secHold
            global holdSecFill6
            holdSecFill6 = newHoldTime

        # Set new Water FINISH time
        def setFinishWater():
            global secFW_Fill6
            global newWaterFinishTime_Fill6
            newWaterFinishTime_Fill6 = changeFinishTimeWater.get()
            secFW_Fill6 = int(newWaterFinishTime_Fill6)# turn string into an int
            newWaterFinishTime_Fill6 = secFW_Fill6


        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, font=('Times', 20), text="Start Water (seconds): ")
        L2.pack()


        # first Water Text Widget
        global newWaterTime_Fill6
        newWaterTime_Fill6 = StringVar()
        newWaterTime_Fill6.set(waterFill6Time) #default water time
        changeTimeWater = tk.Entry(self, font=('Times', 20), text="Water (seconds): ", textvariable=newWaterTime_Fill6)
        changeTimeWater.pack()

        L3 = tk.Label(self, font=('Times', 20), text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime_Fill6
        newHFTime_Fill6 = StringVar()
        newHFTime_Fill6.set(hfFill6Time) # default HF time
        changeTimeHF = tk.Entry(self, font=('Times', 20), text="HF (seconds): ", textvariable=newHFTime_Fill6)
        changeTimeHF.pack()

        L4 = tk.Label(self, font=('Times', 20), text="HNO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime_Fill6
        newHNTime_Fill6 = StringVar()
        newHNTime_Fill6.set(nhFill6Time) # default NHO3 time
        changeTimeHN = tk.Entry(self, font=('Times', 20), text="HNO3 (seconds): ", textvariable=newHNTime_Fill6)
        changeTimeHN.pack()

        L5 = tk.Label(self, font=('Times', 20), text="Hold Time (seconds): ")
        L5.pack()

        # Hold Time Text Widget
        global newHoldTime
        newHoldTime = StringVar()
        newHoldTime.set(holdSecFill6) # default hold time
        changeTimeHold = tk.Entry(self, font=('Times', 20), text="Hold time (seconds): ", textvariable=newHoldTime)
        changeTimeHold.pack()

        L6 = tk.Label(self, font=('Times', 20), text="Finish Water (seconds): ")
        L6.pack()
        # final Water Text Widget
        global newWaterFinishTime_Fill6
        newWaterFinishTime_Fill6 = StringVar()
        newWaterFinishTime_Fill6.set(FWFillTime6) #default water time
        changeFinishTimeWater = tk.Entry(self, font=('Times', 20), text="Water after acids: (seconds): ", textvariable=newWaterFinishTime_Fill6)
        changeFinishTimeWater.pack()

        S2 = tk.LabelFrame(self,font=('Times', 20), height=20)
        S2.pack()

        # save button
        button1 = tk.Button(self, text="save", width=20, font=('Times', 20), height=3, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, font=('Times', 20), height=3, text="return", width=20,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
        callback()        





"_____________________________________Change Fill_Variable______________________________________________"    
class ChangeRecipeFrame_Fill_Variable(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)
                # text.delete('1.0', END)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill(Variable)", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill(Variable) settings saved."
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            print "Hold time set to: " + changeTimeHold.get() + " seconds."
            print "Finish Water time set to: " + changeFinishTimeWater.get() + " seconds."
            text.yview(END)
            setFinishWater()
            setWater()
            setHF()
            setHN()
            setHold()

   
        # Set new Water time
        def setWater():
            global secW_Fill_Variable
            global newWaterTime_Fill_Variable
            newWaterTime_Fill_Variable = changeTimeWater.get()
            secW_Fill_Variable = int(newWaterTime_Fill_Variable)# turn string into an int
            newWaterTime_Fill_Variable = secW_Fill_Variable

        # Set new HF Time
        def setHF():
            global secHF_Fill_Variable
            global newHFTime_Fill_Variable
            newHFTime_Fill_Variable= changeTimeHF.get()
            secHF_Fill_Variable = int(newHFTime_Fill_Variable)  # turn string into an int
            newHFTime_Fill_Variable = secHF_Fill_Variable

        # Set new NHO3 Time
        def setHN():
            global secHN_Fill_Variable
            global newHNTime_Fill_Variable
            
            newHNTime_Fill_Variable = changeTimeHN.get()
            secHN_Fill_Variable = int(newHNTime_Fill_Variable)  # turn string into an int
            newHNTime_Fill_Variable = secHN_Fill_Variable

        # Set new hold Time
        def setHold():
            global secHold
            global newHoldTime
            newHoldTime = changeTimeHold.get()
            secHold = int(newHoldTime)  # turn string into an int
            newHoldTime = secHold
            global holdSecFillV
            holdSecFillV = newHoldTime

        # Set new Water FINISH time
        def setFinishWater():
            global secFW_FillV
            global newWaterFinishTime_FillV
            
            newWaterFinishTime_FillV = changeFinishTimeWater.get()
            secFW_FillV = int(newWaterFinishTime_FillV)# turn string into an int
            newWaterFinishTime_FillV = secFW_FillV



        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, font=('Times', 20), text="Start Water (seconds): ")
        L2.pack()


        # Water Text Widget
        global newWaterTime_Fill_Variable
        newWaterTime_Fill_Variable = StringVar()
        newWaterTime_Fill_Variable.set(waterFillVTime) #default water time
        changeTimeWater = tk.Entry(self, text="Water (seconds): ", font=('Times', 20),
                                   textvariable=newWaterTime_Fill_Variable)
        changeTimeWater.pack()

        L3 = tk.Label(self, font=('Times', 20), text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime_Fill_Variable
        newHFTime_Fill_Variable = StringVar()
        newHFTime_Fill_Variable.set(hfFillVTime) # default HF time
        changeTimeHF = tk.Entry(self, text="HF (seconds): ", font=('Times', 20), textvariable=newHFTime_Fill_Variable)
        changeTimeHF.pack()

        L4 = tk.Label(self, font=('Times', 20), text="HNO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime_Fill_Variable
        newHNTime_Fill_Variable = StringVar()
        newHNTime_Fill_Variable.set(nhFillVTime) # default NHO3 time
        changeTimeHN = tk.Entry(self, text="HNO3 (seconds): ", font=('Times', 20), textvariable=newHNTime_Fill_Variable)
        changeTimeHN.pack()

        L5 = tk.Label(self, font=('Times', 20), text="Hold Time (seconds): ")
        L5.pack()

        # Hold Time Text Widget
        global newHoldTime
        newHoldTime = StringVar()
        newHoldTime.set(holdSecFillV) # default hold time
        changeTimeHold = tk.Entry(self, text="Hold time (seconds): ", font=('Times', 20), textvariable=newHoldTime)
        changeTimeHold.pack()

        S2 = tk.LabelFrame(self, height=20)
        S2.pack()

        L6 = tk.Label(self, font=('Times', 20), text="Finish Water (seconds): ")
        L6.pack()
        # final Water Text Widget
        global newWaterFinishTime_FillV
        newWaterFinishTime_FillV = StringVar()
        newWaterFinishTime_FillV.set(FWFillTimeV) #default water time
        changeFinishTimeWater = tk.Entry(self, font=('Times', 20), text="Water after acids: (seconds): ", textvariable=newWaterFinishTime_FillV)
        changeFinishTimeWater.pack()

        # save button
        button1 = tk.Button(self, text="save", height=3, font=('Times', 20), width=20, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, text="return", height=3, font=('Times', 20), width=20,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
        callback()
        print "Please select an option.\n\n\n\n\n" #main menu message
        text.yview(END)


def refreshGui():
    program.update_idletasks()
    program.update()

######################################Functions.py###########################

    # LOGIC FUNCTIONS FOR VALVES AND PUMP
def fillWater():
    time.sleep(1)
    print "FillWater()"
    if GPIO.input(32) == 0: #Dead man Switch Pressed (Depressed == 0)
        GPIO.output(33, 1)#V4 TO LOW, KEEP DRAIN VALVE CLOSED
        GPIO.output(31, 1)#V3 TO HIGH, LET THE WATER IN
    else:
        print "Dead man signal ***NOT*** received"
        time.sleep(1)
        stop()

def getDrainStatus(): # gets drain status for buttoncolor in GUI
    return drainOpen



def HFfill():
    print "HFfill()"
    time.sleep(1) # Safety delay to make sure all other valves are closed before operation
    if GPIO.input(32) == 0: #Dead man Switch Pressed (Depressed Side == 0)
        print "V1 OPEN"
        GPIO.output(33, 1)#V4 TO LOW, KEEP DRAIN VAVLE CLOSED
        GPIO.output(13,1) #V1 OPEN VALVE FOR HF
    else:
        stop()
        print "No Dead Man Switch Signal(HF FILL)"
        time.sleep(.5)

def NHfill():
    time.sleep(1) # Safety delay to make sure all other valves are closed before operation
    print"NHfill()"
    if GPIO.input(32) == 0: #Dead man Switch Pressed (Depressed Side == 0)
        print "Filling NH03 for 30 seconds"
        
        print "V2 OPEN"
        GPIO.output(33, 1)#V4 TO LOW, KEEP DRAIN VAVLE CLOSED
        GPIO.output(29,1) #V2 OPEN  VALVE FOR NHO3
        time.sleep(1)
    else:
        stop()
        print "No Dead Man Switch Signal(NH FILL)"
        time.sleep(.5)


def allLow(): # to hold solution in tank
    GPIO.output(13, 0)#V1
    GPIO.output(29, 0)#V2
    GPIO.output(31, 0)#V3
    GPIO.output(33, 1)#V4 *****Drain set to default OPEN*****
    GPIO.output(37, 0)#V5

def allLow2(): # to hold solution in tank
    GPIO.output(13, 0)#V1
    GPIO.output(29, 0)#V2
    GPIO.output(31, 0)#V3
    GPIO.output(33, 1)#V4 *****Drain set to default OPEN*****
    GPIO.output(37, 0)#V5

def allLowExit():
    GPIO.output(13, 0)#V1 HF
    GPIO.output(29, 0)#V2 NHO3
    GPIO.output(31, 0)#V3 Water
    GPIO.output(33, 0)#V4 Drain
    GPIO.output(37, 0)#V5 Purge
    GPIO.output(16, 0)# DRIP TRAY ALARM
    GPIO.output(15, 0)# dead man is being pressed confirmation

def waterOpen():
    GPIO.output(31, 1)#V3 TO HIGH H20
    
def waterClose():
    GPIO.output(31, 0)#V3 TO LOW H20
                  
def diWaterFill():
    GPIO.output(13, 0)#V1 TO LOW HF
    GPIO.output(29, 0)#V2 TO LOW NHO3
    GPIO.output(31, 1)#V3 TO HIGH H20
    GPIO.output(33, 1)#V4 TO LOW DRAIN
    GPIO.output(37, 0)#V5 TO LOW PURGE
    print "Water fill signal received, proceeding to fill"
    

def drain():
    GPIO.output(13, 0)#V1 TO LOW HF
    GPIO.output(29, 0)#V2 TO LOW NHO3
    GPIO.output(31, 0)#V3 TO LOW H20
    GPIO.output(33, 0)#V4 TO HIGH DRAIN
    GPIO.output(37, 0)#V5 TO LOW PURGE
    print "Draining . . ."
    global drainOpen
    drainOpen = True

def openDrain():
    GPIO.output(33, 0)#V4 TO HIGH DRAIN
    print "Drain OPEN\n\n\n\n\n"
    global drainOpen
    drainOpen = True

def drainClose():
    GPIO.output(33, 1)#V4 TO LOW DRAIN
    print "Drain CLOSED\n\n\n\n\n"
    global drainOpen
    drainOpen = False

def rinse(): 
    GPIO.output(13, 0)#V1 TO LOW HF
    GPIO.output(29, 0)#V2 TO LOW NHO3
    GPIO.output(31, 1)#V3 TO HIGH H20
    GPIO.output(33, 1)#V4 TO LOW DRAIN
    GPIO.output(37, 0)#V5 TO LOW PURGE
    global drainOpen
    drainOpen = False
  

def purge(): # Purge acid lines
    GPIO.output(13, 1)#V1 TO HIGH HF
    GPIO.output(29, 1)#V2 TO HIGH NHO3
    GPIO.output(31, 0)#V3 TO LOW H20
    GPIO.output(33, 1)#V4 TO LOW DRAIN
    GPIO.output(37, 1)#V5 TO HIGH PURGE

def HFOpen(): # Open HF Valve
    GPIO.output(13, 1)#V1 TO HIGH HF
    print "HF OPEN"
def HFClose(): # Open HF Valve
    GPIO.output(13, 0)#V1 TO LOW HF
    print "HF CLOSED"

def NitOpen(): # Open Nitric Valve
    GPIO.output(29, 1)#V2 TO HIGH NHO3
    print "Nitric OPEN"
def NitClose(): # Open Nitric Valve
    GPIO.output(29, 0)#V2 TO LOW NHO3
    print "Nitric CLOSED"

def n2ON(): # Turn on N2 curtain]
    GPIO.output(n2Pin, 1)
    #print "N2 Curtain ON"

def n2OFF(): # Turn off N2 curtain
    GPIO.output(n2Pin, 0)
    #print "N2 Curtain OFF"

def alarmOff():
        GPIO.output(16, 0) #Alarm OFF
        #print "Alarm OFF"
def alarmOn():
        GPIO.output(16, 1) #Alarm ON
        #print "Alarm ON

def stop():
        GPIO.output(31, 0)#V3 TO LOW H20
        GPIO.output(33, 1)#V4 TO LOW DRAIN
        GPIO.output(37, 0)#V5 TO LOW PURGE
        GPIO.output(13, 0)#V1 TO LOW HF
        GPIO.output(29, 0)#V2 TO LOW NHO3
        global drainOpen
        drainOpen = False
        global stopPressed
        stopPressed = True

                
def restart_program(): #GUI Menu fuctions directly to lxconsole
                allLowExit() # turn all GPIO off 
                python = sys.executable
                os.execl(python, python, * sys.argv)

def restart_pi(): #GUI Menu fuctions directly to lxconsole
                allLowExit() # turn all GPIO off 
                command = "/usr/bin/sudo /sbin/shutdown -r now"
                import subprocess
                process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)
                restartOutput = process.communicate()[0]
                print "Restarting Rpi"


#SETUP
GPIO.setmode(GPIO.BOARD) #use pin number instead of GPIO numbers on Rpi.
GPIO.setwarnings(False)
GPIO.setup(13, GPIO.OUT)#V1 HF
GPIO.setup(37, GPIO.OUT)#V5 PURGE
GPIO.setup(31, GPIO.OUT)#V3 H2O
GPIO.setup(33, GPIO.OUT)#V4 Drain
GPIO.setup(29, GPIO.OUT)#V2 NHO3
GPIO.setup(22, GPIO.IN)#Overfill Sensor
GPIO.setup(32, GPIO.IN)#Dead Man Switch
GPIO.setup(15, GPIO.OUT) # dead man is being pressed
GPIO.setup(18, GPIO.IN) #drip tray moisture sensor
GPIO.setup(16, GPIO.OUT) # Alarm
GPIO.setup(photohelicPin, GPIO.IN) # photohelic pin
GPIO.setup(n2Pin, GPIO.OUT) # n2Pin

 

'''____________________Mainloop_________________________'''


try:
    program = FrameLayout()
    program.attributes('-zoom', True) #change zoom to fullscreen once program is completed
    

    while True:
        #refreshGui()
        program.mainloop()
            
    
except: #if any problems, reset the pi and program
    python = sys.executable
    os.execl(python, python, * sys.argv)
