'''
Author: Spencer Rosenvall
Date: 6/15/2018
Class: TimeoutThread creates a timer.
'''

from threading import *
class timeoutThread:
        
        def timeoutThread(self):
                def hello():
                        print "System timed out"
                print "Timeout initialized . . ."
                t = Timer(5.0, hello) #change to one hour (36,000) secs
                t.start()

        def getCB(self):
                return cb
#t = timeoutThread()
#t.timeoutThread()
