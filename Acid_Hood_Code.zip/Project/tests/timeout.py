#start implementing a thread to do the work

import time
import sys
from Tkinter import *
from datetime import datetime, timedelta

startTime = datetime.now()
finishTime = datetime.now() + timedelta(minutes = .5)

while (startTime < finishTime):
        print "not enough time yet..."
        startTime = datetime.now() 
        time.sleep(1)
if (startTime >= finishTime):
        print "Working!!!!!!!!!!!!!!!!!!!!!!!!!"
        
        


    #tk = Tk()
    
    #startB = Button(tk, text = 'stop', command = timeout)
    #startB.pack()
    #tk.mainloop()

