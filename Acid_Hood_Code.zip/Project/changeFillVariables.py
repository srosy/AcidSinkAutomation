'''**********************************************
* Author: Spencer Rosenvall
* ChangeFillVariables: Code to change and update
* fill variables in main Acid Hood GUI 
***********************************************'''

from Tkinter import *
import Tkinter as tk

"_____________________________________________Change Fill 1_________________________________________________" 
class ChangeRecipeFrame(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill1", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill 1 settings saved"
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            text.yview(END)
            setWater()
            setHF()
            setHN()

   
        # Set new Water time
        def setWater():
            global secW
            global newWaterTime
            newWaterTime = changeTimeWater.get()
            secW = int(newWaterTime)# turn string into an int
            newWaterTime = secW

        # Set new HF Time
        def setHF():
            global secHF
            global newHFTime
            newHFTime = changeTimeHF.get()
            secHF = int(newHFTime)  # turn string into an int
            newHFTime = secHF

        # Set new NHO3 Time
        def setHN():
            global secHN
            global newHNTime
            newHNTime = changeTimeHN.get()
            secHN = int(newHNTime)  # turn string into an int
            newHNTime = secHN


        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, text="Water (seconds): ")
        L2.pack()


        # Water Text Widget
        global newWaterTime
        newWaterTime = StringVar()
        newWaterTime.set(11) #default water time
        changeTimeWater = tk.Entry(self, text="Water (seconds): ", textvariable=newWaterTime)
        changeTimeWater.pack()

        L3 = tk.Label(self, text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime
        newHFTime = StringVar()
        newHFTime.set(11) # default HF time
        changeTimeHF = tk.Entry(self, text="HF (seconds): ", textvariable=newHFTime)
        changeTimeHF.pack()

        L4 = tk.Label(self, text="HNO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime
        newHNTime = StringVar()
        newHNTime.set(11) # default NHO3 time
        changeTimeHN = tk.Entry(self, text="HNO3 (seconds): ", textvariable=newHNTime)
        changeTimeHN.pack()

        S2 = tk.LabelFrame(self, height=20)
        S2.pack()

        # save button
        button1 = tk.Button(self, text="save", width=6, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, text="return", width=6,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
       
        global text
        text = Text(width=50, height=5)
        text.pack(anchor=N)
        callback()
     
"______________________________________________Change Fill 2______________________________________________"    
class ChangeRecipeFrame_Fill2(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)
                # text.delete('1.0', END)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill2", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill 2 settings saved."
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            text.yview(END)
            setWater()
            setHF()
            setHN()

   
        # Set new Water time
        def setWater():
            global secW_Fill2
            global newWaterTime_Fill2
            newWaterTime_Fill2 = changeTimeWater.get()
            secW_Fill2 = int(newWaterTime_Fill2)# turn string into an int
            newWaterTime_Fill2 = secW_Fill2

        # Set new HF Time
        def setHF():
            global secHF_Fill2
            global newHFTime_Fill2
            newHFTime_Fill2 = changeTimeHF.get()
            secHF_Fill2 = int(newHFTime_Fill2)  # turn string into an int
            newHFTime_Fill2 = secHF_Fill2

        # Set new NHO3 Time
        def setHN():
            global secHN_Fill2
            global newHNTime_Fill2
            newHNTime_Fill2 = changeTimeHN.get()
            secHN_Fill2 = int(newHNTime_Fill2)  # turn string into an int
            newHNTime_Fill2 = secHN_Fill2


        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, text="Water (seconds): ")
        L2.pack()


        # Water Text Widget
        global newWaterTime_Fill2
        newWaterTime_Fill2 = StringVar()
        newWaterTime_Fill2.set(22) #default water time
        changeTimeWater = tk.Entry(self, text="Water (seconds): ", textvariable=newWaterTime_Fill2)
        changeTimeWater.pack()

        L3 = tk.Label(self, text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime_Fill2
        newHFTime_Fill2 = StringVar()
        newHFTime_Fill2.set(22) # default HF time
        changeTimeHF = tk.Entry(self, text="HF (seconds): ", textvariable=newHFTime_Fill2)
        changeTimeHF.pack()

        L4 = tk.Label(self, text="HNO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime_Fill2
        newHNTime_Fill2 = StringVar()
        newHNTime_Fill2.set(22) # default NHO3 time
        changeTimeHN = tk.Entry(self, text="HNO3 (seconds): ", textvariable=newHNTime_Fill2)
        changeTimeHN.pack()

        S2 = tk.LabelFrame(self, height=20)
        S2.pack()

        # save button
        button1 = tk.Button(self, text="save", width=6, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, text="return", width=6,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
        callback()

"_______________________________________________Change Fill 3______________________________________________"    
class ChangeRecipeFrame_Fill3(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill3", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill 3 settings saved."
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            text.yview(END)
            setWater()
            setHF()
            setHN()

   
        # Set new Water time
        def setWater():
            global secW_Fill3
            global newWaterTime_Fill3
            newWaterTime_Fill3 = changeTimeWater.get()
            secW_Fill3 = int(newWaterTime_Fill3)# turn string into an int
            newWaterTime_Fill3 = secW_Fill3

        # Set new HF Time
        def setHF():
            global secHF_Fill3
            global newHFTime_Fill3
            newHFTime_Fill3 = changeTimeHF.get()
            secHF_Fill3 = int(newHFTime_Fill3)  # turn string into an int
            newHFTime_Fill3 = secHF_Fill3

        # Set new NHO3 Time
        def setHN():
            global secHN_Fill3
            global newHNTime_Fill3
            newHNTime_Fill3 = changeTimeHN.get()
            secHN_Fill3 = int(newHNTime_Fill3)  # turn string into an int
            newHNTime_Fill3 = secHN_Fill3


        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, text="Water (seconds): ")
        L2.pack()


        # Water Text Widget
        global newWaterTime_Fill3
        newWaterTime_Fill3 = StringVar()
        newWaterTime_Fill3.set(33) #default water time
        changeTimeWater = tk.Entry(self, text="Water (seconds): ", textvariable=newWaterTime_Fill3)
        changeTimeWater.pack()

        L3 = tk.Label(self, text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime_Fill3
        newHFTime_Fill3 = StringVar()
        newHFTime_Fill3.set(33) # default HF time
        changeTimeHF = tk.Entry(self, text="HF (seconds): ", textvariable=newHFTime_Fill3)
        changeTimeHF.pack()

        L4 = tk.Label(self, text="HNO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime_Fill3
        newHNTime_Fill3 = StringVar()
        newHNTime_Fill3.set(33) # default NHO3 time
        changeTimeHN = tk.Entry(self, text="HNO3 (seconds): ", textvariable=newHNTime_Fill3)
        changeTimeHN.pack()

        S2 = tk.LabelFrame(self, height=20)
        S2.pack()

        # save button
        button1 = tk.Button(self, text="save", width=6, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, text="return", width=6,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
        callback()


"___________________________________________Change Fill_Variable______________________________________________"    
class ChangeRecipeFrame_Fill_Variable(tk.Frame):
    def __init__(self, parent, controller):

        class PrintText(object):
            def write(self, s):
                text.insert(END, s)
                # text.delete('1.0', END)

        sys.stdout = PrintText()

        tk.Frame.__init__(self, parent)
        label = tk.Label(self, text="Recipe Configuration_Fill(Variable)", font=('Times', 15))
        label.pack(pady=10, padx=10)

        # Save Settings
        def callback():
            print "Fill(Variable) settings saved."
            print "Water time set to: " + changeTimeWater.get() + " seconds."
            print "HF time set to: " + changeTimeHF.get() + " seconds."
            print "HNO3 time set to: " + changeTimeHN.get() + " seconds."
            text.yview(END)
            setWater()
            setHF()
            setHN()

   
        # Set new Water time
        def setWater():
            global secW_Fill_Variable
            global newWaterTime_Fill_Variable
            newWaterTime_Fill_Variable = changeTimeWater.get()
            secW_Fill_Variable = int(newWaterTime_Fill_Variable)# turn string into an int
            newWaterTime_Fill_Variable = secW_Fill_Variable

        # Set new HF Time
        def setHF():
            global secHF_Fill_Variable
            global newHFTime_Fill_Variable
            newHFTime_Fill_Variable= changeTimeHF.get()
            secHF_Fill_Variable = int(newHFTime_Fill_Variable)  # turn string into an int
            newHFTime_Fill_Variable = secHF_Fill_Variable

        # Set new NHO3 Time
        def setHN():
            global secHN_Fill_Variable
            global newHNTime_Fill_Variable
            newHNTime_Fill_Variable = changeTimeHN.get()
            secHN_Fill_Variable = int(newHNTime_Fill_Variable)  # turn string into an int
            newHNTime_Fill_Variable = secHN_Fill_Variable

        def fillVar(event):
            

            
            # Timer to display seconds   
            def tick():
                global go
                global sec
                global currentSec
                global newWaterTime
                global saveNH
                global saveHF
                global saveWater
                global state
                global fillOption #controls which tickW, tickHF, tickNH to use form inside tick()
                global mayProceed
                
                
                def pause():
                    print"Paused, Hold Deadman switch to resume"
                    print "Warning, failing to hold dead man switch again will result in auto-drain and rinse."
                    global autoNumberTimesLeft
                    autoNumberTimesLeft = 3
                    

                    def autoDrainRinse(): # function to automatically drain  and rinse as penalty for not holding dmain switch
                        global y
                        y = 5
                        global z
                        z = 5
                        
                        def autoDrain():
                            print "inside of autoDrain"
                            drain()
                            text.yview(END)
                            if y == 0:
                                autoRinse()
                            if y <= 5 and not y == 0:
                                global y
                                print ("Total seconds remaining to drain: %s\ncurrent round: %s" %(y, autoNumberTimesLeft))
                                y -= 1
                                text.yview(END)
                                time.after(1000, autoDrain)
                        def autoRinse():
                            print "inside of autoRinse"
                            text.yview(END)
                            rinse()
                            if z == 0:
                                global autoNumberTimesLeft
                                autoNumberTimesLeft -= 1
                                time.after(1000, autoDrainRinse)
                            if z == 0 and autoNumberTimesLeft == 0: # this works appropriately
                                stop()
                                drain()
                                print"Final drain commencing"
                                global allowNoStop
                                allowNoStop = 0
                                text.yview(END);
                                
                            if z >=1:
                                global z
                                print ("Total seconds remaining to rinse: %s\ncurrent round: %s" %(z, autoNumberTimesLeft))
                                z -= 1
                                text.yview(END)
                                time.after(1000, autoRinse)

                        if autoNumberTimesLeft > 0:
                            stop() #make sure everything is off before opening more valves
                            autoDrain()
                        
                                
                    def count():
                        
                        if GPIO.input(32) == 0:
                            if  mayProceed == 1:
                                global warning
                                warning = 1
                                warningMessage() #warning popup at 5 seconds
                                return
                            else:
                                global x
                                print ("Total seconds paused: %s\n" %x)
                                x += 1
                                text.yview(END)
                                time.after(1000, count)

                        if warning == 1 and x >= 5: #x amount of seconds before auto rinse for penalty
                            global alreadyOperating
                            alreadyOperating == 1l
                            
                            if GPIO.input(32) == 1: #while no deadman switch it detected
                                def waitForUser():
                                    global x
                                    print ("Total seconds paused: %s\n" %x)
                                    x += 1
                                    text.yview(END)
                                    if GPIO.input(32) == 0:
                                        autoDrainRinse()
                                        return
                                    time.after(1000, waitForUser)
                                waitForUser()
                            dManTimeout()
                            return alreadyOperating
                       
                        
                        if GPIO.input(32) == 1:
                            global x
                            print ("Total seconds paused: %s\n" %x)
                            x += 1
                            text.yview(END)
                            time.after(1000, count)

                    def refusal():
                        text.yview(END)
                        print"Cannot delete window, must press\nresume with DeadMan"
                        text.yview(END)

                    def checkState():
                        if state == 1:
                            intruction = Label(rootB, text='Paused during ***WATER*** with %d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                               font=('Times', 25), bg ='red') 
                            intruction.pack()
                            
                        if state == 2:
                            intruction = Label(rootB, text='Paused during ***HF*** with %d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                               font=('Times', 25), bg ='red') 
                            intruction.pack()

                        if state == 3:
                            intruction = Label(rootB, text='Paused during ***NHO3*** with %d seconds remaining\nNOTE: FILL INCOMPLETE' % sec,
                                               font=('Times', 25), bg ='red') 
                            intruction.pack()
                            
                        count() # timer that counts up for dead man pause

      
                    global rootB
                    global sec
                    global state
                    rootB = Tk()
                    rootB.attributes('-topmost', 1)
                    rootB.geometry("800x270")# Window dimensions(w x h + starting w + starting h)
                    rootB.config(bg='red')
                    rootB.protocol('WM_DELETE_WINDOW', refusal) #override the x close button
                    rootB.title('No Deadman Signal Detected')
                    intruction = Label(rootB, text='Press resume to continue', font=('Times', 45), bg ='red') 
                    intruction.pack()
                    resumeB = Button(rootB, text='Resume', height = 5, width = 20, command=resumeState) 
                    resumeB.pack()
                    checkState()
                   
                    
                    
                def resumeState():
                    if GPIO.input(32) == 0:
                        global rootB
                        rootB.destroy()
                        global mayProceed # gets you out of the dman screen counter
                        mayProceed = 1
                        if state == 1:
                            fillWater()
                            tick()
                            print "Resuming Water\n"
                            text.yview(END)
                        if state == 2:
                            HFfill()
                            print "Resuming HF\n"
                            text.yview(END)
                            tick()
                        if state == 3:
                            NHfill()
                            print "Resuming NHO3\n"
                            text.yview(END)
                            tick()
                        if warning == 1 and x >= 5: #setting x for dman timeout second time
                            finishTimer()
                            global alreadyOperating
                            alreadyOperating = 1
                            global allowNoStop # control bit to not allow stop button to stop autoDrainRinse
                            allowNoStop = 1
                            #TODO: add drain and rinse function here that can't be stopped until finished
                    if GPIO.input(32) == 1:
                        print "Hold DeadMan and press resume"
                        text.yview(END)
                    

                
                 #Countdown to Timeout Timer(Currently unused)  
                def countdownTimer():
                    if x >= 0 and not GPIO.input(32) == 0 :
                        print ("TimeOut in: %s. HOLD DeadMan switch to resume." % x)
                        text.yview(END)
                        global x
                        x = x - 1
                        time.after(1000, countdownTimer)
                        if x == -1 and GPIO.input(32) == 1:
                            print"Process Timed Out."
                            stop()
                            tickReset()
                        return sec


                if GPIO.input(32)==1:
                    global saveSec
                    saveSec = sec
                    stop()
                    global x
                    x = 0
                    global mayProceed
                    mayProceed = 0
                    pause()
                    
                    
                
                 #Tick Continuation   
                if sec > 0 and GPIO.input(32) == 0:
                    global sec
                    sec -= 1
                    #print sec
                    time['text'] = sec
                    
                    #Water Tick
                    if sec > 0 and go == 1 and goHF == 0 and goNH == 0 and GPIO.input(32) == 0:
                        if GPIO.input(32) == 0:
                            time.after(1000, tick)
                            print ("Water Tick: %s\n" %sec)
                            global state
                            state = 1
                            text.yview(END)
                            return sec

                    #HF Tick
                    if sec > 0 and go == 1 and goHF == 1 and goNH == 0 and GPIO.input(32) == 0:
                        if GPIO.input(32) == 0:
                            time.after(1000, tick)
                            print ("HF Tick: %s\n" %sec)
                            global state
                            state = 2
                            text.yview(END)
                            return sec

                    #NHO3 Tick
                    if sec > 0 and go == 1 and goHF == 1 and goNH == 1 and GPIO.input(32) == 0:
                        if GPIO.input(32) == 0:
                            time.after(1000, tick)
                            print ("NHO3 Tick: %s\n" %sec)
                            global state
                            state = 3
                            text.yview(END)
                            return sec

                    #Start HF Timer
                    if sec == 0 and go == 1 and goHF == 0 and goNH == 0 and GPIO.input(32) == 0:
                        time['text'] = sec
                        stop()
                        
                        print "Water Complete"
                        text.yview(END)
                        
                        

                        if fillOption is 1:
                            print ("Starting HF Timer: %s seconds." % newHFTime)
                            text.yview(END)
                            tickHF()
                            print"tickHF"
                            text.yview(END)
                            return sec

                        if fillOption is 2:
                            print ("Starting HF Timer: %s seconds." % newHFTime_Fill2)
                            text.yview(END)
                            tickHF2()
                            print"tickHF2"
                            text.yview(END)
                            return sec

                        if fillOption is 3:
                            print ("Starting HF Timer: %s seconds." % newHFTime_Fill3)
                            text.yview(END)
                            tickHF3()
                            print"tickHF3"
                            text.yview(END)
                            return sec

                        if fillOption is 4:
                            print ("Starting HF Timer: %s seconds." % newHFTime_Fill_Variable)
                            text.yview(END)
                            tickHFV()
                            print"tickHF4"
                            text.yview(END)
                            return sec

                    #Start HNO3 Timer
                    if sec == 0 and goHF == 1 and goNH == 0 and go == 1 and GPIO.input(32) == 0:
                        global saveNH
                        global saveHF
                        global saveWater
                        saveHF = 0
                        saveNH = 1
                        saveWater = 0
                        
                        time['text'] = sec
                        stop()
                        print "HF Complete"
                        text.yview(END)
                        
                        print ("Starting HNO3 Timer: %s seconds." % newHNTime)
                        text.yview(END)

                        if fillOption is 1:
                            tickNH()
                            print"tickHF"
                            text.yview(END)
                            return sec

                        if fillOption is 2:
                            tickNH2()
                            print"tickHF2"
                            text.yview(END)
                            return sec

                        if fillOption is 3:
                            tickNH3()
                            print"tickHF3"
                            text.yview(END)
                            return sec

                        if fillOption is 4:
                            tickNHV()
                            print"tickHF4"
                            text.yview(END)
                            return sec
                        
                            
                    #Finish Timer
                    if sec == 0 and goHF == 1 and goNH == 1 and go == 1 and GPIO.input(32) == 0:
                        finishTimer()
                                
            #finish timer
            def finishTimer():
                stop()
                text.yview(END)
                global fillOption
                fillOption = 0
                print "Operation Complete."
                text.yview(END)
                global alreadyOperating
                alreadyOperating = 0
                global warning
                warning = 0
             
                global fwV
                
                fwV = 0
                tickReset()

            def fillproc_eventV():
                text.yview(END)
                if (GPIO.input(32) == 0 and alreadyOperating == 0 and (superUser == 1 or isSupervisor == 1)):
                    global fwV
                    fwV = 1
                    fillWater() #Function.py
                    tickWV()
                else:
                    if alreadyOperating == 1:
                        isOperating()
                    elif ((superUser == 0 and isSupervisor == 0) and GPIO.input(32) == 1):
                        print "Supervisor permission required."
                    else:
                        print "No DeadMan Switch Signal"
                text.yview(END)
                
            fillproc_eventV() #start fillproc_event when tick is called


        

        L1 = tk.Label(self, text="New Recipe Parameters", font=('Times', 10))
        L1.pack()
        S1 = tk.LabelFrame(self)
        S1.pack()

        L2 = tk.Label(self, text="Water (seconds): ")
        L2.pack()


        # Water Text Widget
        global newWaterTime_Fill_Variable
        newWaterTime_Fill_Variable = StringVar()
        newWaterTime_Fill_Variable.set(44) #default water time
        changeTimeWater = tk.Entry(self, text="Water (seconds): ",
                                   textvariable=newWaterTime_Fill_Variable)
        changeTimeWater.pack()

        L3 = tk.Label(self, text="HF (seconds): ")
        L3.pack()

        # HF Text Widget
        global newHFTime_Fill_Variable
        newHFTime_Fill_Variable = StringVar()
        newHFTime_Fill_Variable.set(44) # default HF time
        changeTimeHF = tk.Entry(self, text="HF (seconds): ", textvariable=newHFTime_Fill_Variable)
        changeTimeHF.pack()

        L4 = tk.Label(self, text="HNO3 (seconds): ")
        L4.pack()

        # HNO3 Text Widget
        global newHNTime_Fill_Variable
        newHNTime_Fill_Variable = StringVar()
        newHNTime_Fill_Variable.set(44) # default NHO3 time
        changeTimeHN = tk.Entry(self, text="HNO3 (seconds): ", textvariable=newHNTime_Fill_Variable)
        changeTimeHN.pack()

        S2 = tk.LabelFrame(self, height=20)
        S2.pack()

        # save button
        button1 = tk.Button(self, text="save", width=6, command=callback)
        button1.pack()

        # return button
        button2 = tk.Button(self, text="return", width=6,
                            command=lambda: controller.show_frame(FillChangeFrame))
        button2.pack()
        callback()
        print "\n\n\n"
        text.yview(END)

    
